EXHIBIT 10.1 

BUSINESS AFFILIATE AGREEMENT 

This  Business  Affiliate  Agreement   ("Agreement")  dated  January  28,  2005, effective  as of October 15,  2004,  ("Effective  Date") is entered  into by and between Dr. George D. Green (the "Business Affiliate") and UNION DENTAL CORP., a Florida  corporation  ("UDC")  (collectively,  Business Affiliate and UDC may be referred to collectively as the "Parties" and singularly as a ("Party"). 

WHEREAS,  the Business  Affiliate  wishes to help further  UDC's mission of Managing  dental  offices,  whereby  Business  Affiliate  and UDC will  exchange confidential information (as defined below): 

NOW THEREFORE,  in consideration of the premises,  covenants and agreements and  the  mutual   promises   herein   made,   and  in   consideration   of  the representations,  warranties, and covenants herein contained, and for other good and  valuable  consideration,  the  receipt and  sufficiency  of which is hereby acknowledged, the Parties hereto agree as follows: 

1.  Definitions.  A  Confidential  Information@  shall  mean  any  and  all information  that a Party may reasonably  expect to remain  confidential and not shared with the general public at any time or that information that is protected by law. 

2.  Services.  It is anticipated  that the Business  Affiliate will provide services both for clients of the Business Affiliate and UDC that involve the use and disclosure of Confidential Information (the "Services"). Except as otherwise specified  herein,  the  Parties  may  make  any  and all  uses of  Confidential Information  necessary to perform the  Services.  Additionally,  the Parties may disclose Confidential  Information for the purposes authorized by this Agreement only (a) to its employees,  subcontractors  and agents,  in accordance with this Agreement,  or (b) as directed by the other Party.  The Parties  expressly agree that any and all uses or disclosures of the Confidential  Information by a Party will be done in accordance  with the terms of this  Agreement and the provisions of all applicable federal and state laws and regulations. 

3.  Responsibilities  of  the  Parties.  With  regard  to  its  use  and/or disclosure  of  Confidential  Information,  each Party  hereby  agrees to do the following: 

a. Use and/or disclose the Confidential  Information only as permitted or required by this Agreement or as otherwise required by law; 

1 

b. Report to the other Party, in writing, any use and/or disclosure of the  Confidential  Information  that is not  permitted  or required by this Agreement of which a Party  becomes aware within five (5) days of a Party=s discovery of such unauthorized use and/or disclosure; c.  Use  appropriate  safeguards  to  maintain  the  security  of  the Confidential  Information and to prevent unauthorized use and/or disclosure of such Confidential Information; d. Require all of its employees,  representatives,  subcontractors  or agents that receive or use or have access to Confidential Information under this Agreement to agree in writing to adhere to the same  restrictions  and conditions on the use and/or  disclosure of Confidential  Information  that apply  herein,   including   the   obligation  to  return  or  destroy  the Confidential Information as provided under paragraph g of this Section 3. e. Make available,  during normal business hours, at a Party=s offices all records, books, agreements, policies and procedures relating to the use and/or  disclosure  of  Confidential  Information  that is  subject to this Agreement,  to the other  Party  within ten (10) days of a Party's  written request,  for the purpose of  enabling a Party to verify the other  Party=s compliance with the terms of this Agreement; f. Within  fifteen  (15) days of  receiving a written  request  from a Party,  provide to the other Party such  information  as is  requested by a Party to permit the other  Party to  respond  to a request  by the  subject individual for amendment and accounting  purposes of the disclosures of the individual=s Confidential Information; 

g.  Return to a Party or  destroy,  as  requested  by a Party,  within fifteen (15) days of the  termination of this Agreement,  any  Confidential Information  provided  to such  Party and in its  possession  and retain no copies or back-up tapes; h. Parties agrees to mitigate, to the extent practicable,  any harmful effect  that is  known to a Party of a use or  disclosure  of  Confidential Information by a Party in violation of the requirements of this Agreement; i. To inform a Party of any  changes  in the form of notice of privacy practices  that the other  Party  provides to  individuals  and provide the Party a copy of the notice currently in use; and 

j. To  inform  the Party of any  changes  in, or  withdrawal  of,  the consent  or  authorization   provided  to  a  Party  by  individuals  whose Confidential Information may be used and/or disclosed by a Party under this Agreement. 

2 

Source: UNION DENTAL HOLDINGS, INC., 8-K/A, 2/4/2005 

4. Mutual  Representation and Warranty.  Each Party represents and warrants 

to the  other  Party  that all of its  employees,  agents,  representatives  and members of its work force,  whose  services  may be used to fulfill  obligations under this  Agreement,  are or shall be  appropriately  informed of the terms of this  Agreement  and are  under  legal  obligation  to  comply  fully  with  all provisions of this Agreement. 

5. Term and Termination. 

a. Term. This Agreement  shall become  effective on the Effective Date and shall  continue in effect until  either  Party  informs the other Party with thirty (30) day prior written notice of termination of this Agreement. b. Termination.  UDC may immediately  terminate this Agreement without notice  and any  related  agreement  if it  determines  that  the  Business Affiliate  has breached a material  provision  of this  Agreement or if the activities  contemplated under this Agreement will result in a violation of any federal or state law or if such Services  would,  in the opinion of UDC and its counsel. Alternatively, UDC may choose to: (i) provide the Business Affiliate  with ten (10) days written notice of the existence of an alleged material breach;  and (ii) afford the Business  Affiliate an opportunity to cure said alleged material breach upon mutually agreeable terms. Failure to cure in the manner set forth in this paragraph is grounds for the immediate termination of the Agreement. c. Effect of Termination.  Upon termination of this Agreement, for any reason, each Party hereto shall return to the other Party, or destroy,  all of such Party's  Confidential  Information  in the  possession of the other Party.  This provision shall apply to Confidential  Information  that is in the possession of  subcontractors or agents of each Party. Each Party shall retain no copies of the Confidential  Information of the other Party except as may be required by law. 

6. Indemnification.  The Parties hereby covenant and agree to indemnify and hold harmless each other, it's agents and  representatives  from and against any and all losses, costs, expenses, liabilities, claims, demands, judgments and its settlements  of every  nature that are actually  incurred by a Party,  including without limitation reasonable attorney's fees for pre-trial,  trial,  appellate, judgment,  post-judgment,  execution, and alternative dispute resolution,  which arise out of any use or disclosure of Confidential  Information not specifically permitted by this  Agreement  or arise out of the services  rendered by Business Affiliate.  The provisions of this Paragraph 6 shall survive the  termination of this Agreement for whatever reasons whatsoever. 

7. Miscellaneous. 

a.  Survival.  The  respective  rights  and  obligations  of  Business Affiliate  and UDC under the  provisions  of **Sections  3(g)** **_[Responsibilities of the Parties]_** and **3(h)** **_[Responsibilities of the Parties]_** and 6 shall survive the termination of this Agreement indefinitely. 

3 

b. Amendment. This Agreement may not be modified or amended, except in writing as agreed to by each Party. 

c. No Third Party  Beneficiaries.  Nothing  express or implied in this Agreement is intended to confer, nor anything herein shall confer, upon any person other than the Parties hereto any rights, remedies,  obligations, or liabilities whatsoever. 

d.  Notices.  All  notices or  communications  required  or  permitted pursuant  to the terms of this  Agreement  will be in  writing  and will be delivered in person or by means of certified or  registered  mail,  postage prepaid, return receipt requested, to such Party at its last known address, or such other person or address as such Party may specify by similar notice to the other Party hereto or by telephone  facsimile  with a hard copy sent by mail on the next  business  day.  All such  notices will be deemed given upon delivery if delivered by hand, on the third business day after deposit with the U.S. Postal  Service,  and on the first business day after sending it by facsimile. 

e. Relationship of the Parties. It is expressly  understood and agreed that (i) in the performance of Services under this Agreement,  the Business Affiliate shall at all times act as an independent  contractor with respect to UDC and not as an employee or agent of UDC and (ii) nothing contained in this Agreement  shall be construed to create a joint venture,  partnership, association  or  other  affiliation,  or  like  relationship,  between  the Parties,  it being  specifically  agreed that the relationship is and shall remain  that  of  independent   Parties  to  a  contractual   relationship. Accordingly,  UDC shall  neither have nor exercise any specific  control or direction over the particular  methods by which Business Affiliate performs services  required by this  Agreement.  In no event shall  either  Party be liable  for the debts or  obligations  of the  other,  except as  otherwise specifically provided in this Agreement. Neither Party shall have any claim under this Agreement or otherwise against the other Party for vacation pay, paid  sick  leave,   retirement   benefits,   social   security,   worker=s compensation, health, disability,  professional malpractice or unemployment insurance  benefits,  or other employee  benefits of any kind. Based on the foregoing, (i) Business Affiliate will not be treated as an employee of UDC for Federal tax  purposes;  (ii) UNION DENTAL  CORP.,  will not withhold on behalf  of  Business  Affiliate  any  sums  for  income  tax,  unemployment insurance,  social security or any other withholding pursuant to any law or requirement of any  government  body, or make available any of the benefits afforded to employees of UDC (iii) all of such  payments,  withholdings  or benefits due any governmental agency, if any, are Business Affiliate=s sole responsibility;  and  (iv)  Business  Affiliate  will  indemnify  and  hold harmless UDC from any and all loss or liability arising from his failure to make  such  payments,  withholds  and  benefits,  if any.  In the event the Internal Revenue Service or any other  governmental  agency should question or challenge the Business  Affiliate=s  independent  contractor status, the Parties  hereby agree that both  Business  Affiliate and UDC shall have the right to participate in any discussions or negotiations 

Source: UNION DENTAL HOLDINGS, INC., 8-K/A, 2/4/2005 

4 

occurring with such agency or agencies,  regardless of with whom or by whom such discussions or negotiations are initiated. 

f. Business  Affiliate  acknowledges  that the Business  Affiliate has read,  understood  and accepted the terms and  conditions in UDC's Business Affiliate manual, the terms and conditions of which are hereby incorporated into this agreement by reference. 

IN WITNESS  WHEREOF,  the Parties  hereto have caused this  Agreement to be signed as of the date and year first above written. 

Business Affiliate -------------------------------By: /s/ George D. Green -------------------------------Name: George D. Green -------------------------------Title: -------------------------------UNION DENTAL CORP. 

By: /s/ George D. Green -------------------------------Name: George D. Green -------------------------------Title:CEO and President -------------------------------- 

udc-8ka_ex10baa1.doc 

5 

Source: UNION DENTAL HOLDINGS, INC., 8-K/A, 2/4/2005 

