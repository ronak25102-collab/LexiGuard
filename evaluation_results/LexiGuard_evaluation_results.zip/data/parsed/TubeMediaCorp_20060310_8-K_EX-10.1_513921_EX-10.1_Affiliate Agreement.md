**_Execution Copy_** 

# <u>CHARTER AFFILIATE AFFILIATION AGREEMENT</u> 

THIS AGREEMENT (the “Agreement”), made as of the 6<sup>th</sup> day of March, 2006 (the “Effective Date”), is by and between The TUBE Music Network, Inc., a Florida corporation (the “Network”), and Tribune Broadcasting Company, a Delaware corporation (“Affiliate”), regarding the television programming service currently known as “The TUBE” (the “Service”). The parties hereby mutually agree as follows: 

# 1.  DEFINITIONS: 

In addition to any other defined terms in this Agreement, the following terms shall have the following meanings when used in this 

Agreement: 

“Acquired Station” means any Broadcast Television station that is acquired by Affiliate after the Effective Date. 

“Affiliate Advertising Share” has the meaning set forth in Exhibit D. 

“Affiliate Launch Date” means the date on which the Service is initially transmitted by the first of Affiliate’s Stations. 

“Affiliate Transactional Share” has the meaning set forth in Exhibit D. 

“Broadcast Television” means traditional, free, FCC-licensed, over-the-air broadcast television. 

“Charter Affiliate” means a Broadcast Television station or station group that (i) entered into an affiliation agreement with the Network on or before the date of this Agreement, and/or (ii) is owned, operated or licensed to Sinclair Television Group, Inc. or an affiliate thereof. 

“Costs” means all losses, liabilities, claims, costs, damages and expenses, including fines, forfeitures, reasonable attorneys’ and expert witness fees, disbursements and court or administrative costs. 

“Designated Market Area” or “DMA” means a particular market area or classification to demarcate local television markets as defined by Nielsen Media Research, Inc. from time-to-time, or, if DMA falls from general or standardized usage, a replacement term to demarcate local television markets in a substantially similar manner which shall be determined by the parties in good faith. 

“Licensed Community” has the meaning set forth in Section 3(a). 

“Local Advertising” has the meaning set forth in Section 8(c). 

“MVPD” means a multichannel video program distributor as such term is set forth in 47 C.F.R. §76.905(d) of the rules of the Federal Communications Commission (“FCC”). 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

“Network’s Advertising Revenue” means the gross dollar amount of collections received by or credited to Network from the sale by Network of commercial advertising time included in the Service, less actual agency representative fees and sales commissions. For clarification, Network’s Advertising Revenue shall not include accounts receivable or Network’s Transactional Revenue. 

“Network’s Transactional Revenue” means the gross dollar amount of revenue actually received by Network ( _e.g._ , net of the cost of goods and services and all fulfillment costs associated with the sale of such goods and services) from (i) the sale of products and services by way of direct response telephone orders from the toll-free number included on the Service, and (ii) e-commerce sales of products and services by or on behalf of Network over the Internet originating from Network’s website ( _i.e.,_ URL www.thetubetv.com or any replacement or supplemental URL) or Affiliate’s website, in all cases, originating from within the Zip Codes in the DMA of the Station(s) transmitting the Service, and from Zip Codes in the DMA of any MVPD(s) that carry a Station if, at the time of the sale, Network does not have an affiliation with a Broadcast Station that is transmitting the Service and whose Licensed Community is located in such DMA. 

“Primary Feed” means the audio and video presentations of each Station’s primary one-way over-the-air digital television signal (which signal may be in either standard definition or high definition television (as such term is defined by the Advanced Television Systems Committee) format). 

“Promotional Spots” has the meaning set forth in Section 8(a). 

“Service” means the television programming service provided by Network as defined in the preamble to this Agreement. 

- “Station(s)” means a Broadcast Television station licensed to Affiliate or a subsidiary of Affiliate by the FCC that provides or is 

- capable of providing the Service to the Licensed Community that it is licensed to serve. 

- “TV Households” means the number of television households in a given DMA as determined by Nielsen Media Research, Inc. 

- (which, as of the date hereof, is published annually by Nielsen Media Research, Inc. as the Nielsen Media Research Local Universe Estimates (US)) or, if Nielsen Media Research, Inc. ceases to publish the number of television households in a DMA, a replacement term to determine the number of television households in local television markets in a substantially similar manner which shall be determined by the parties in good faith. 

- “Zip Code(s)” means a specific geographic delivery area defined by the United States Postal Service, which consists of a five (5)- 

- digit zip code plus a four (4)-digit add-on code. 

# 2.TERM, EXTENSION AND RENEWAL: 

(a) Initial Term. Unless terminated earlier in accordance with the terms of this Agreement, the “Term” of this Agreement shall consist of, collectively, the Initial Term and the Renewal Term, if applicable. The “Initial Term” shall commence upon the Effective Date and shall expire on March 31, 2011. 

2 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(b) Renewal Term. If Affiliate fails to notify Network of its desire that this Agreement terminate on its expiration date, at least six (6) months before the expiration date, this Agreement will automatically renew, upon the same terms and conditions, for an additional four (4) -year period (“Renewal Term”). 

(c) If the Term is renewed as described in Section 2(b), Network and Affiliate will negotiate exclusively and in good faith concerning further renewal of this Agreement upon mutually-agreed terms and conditions; provided, that unless Network and Affiliate otherwise agree in writing, the exclusive negotiation period will end six (6) months before the expiration of the Term. 

# 3.GRANT OF RIGHTS; ACQUIRED STATIONS: 

(a) Network hereby grants to Affiliate the exclusive right via Broadcast Television, and Affiliate hereby accepts such exclusive right and the obligation during the Term to broadcast the Service via Broadcast Television (i) over the transmission facilities of each Station identified on Exhibit A, which is licensed by the FCC to serve the community for each such Station (the “Licensed Community”), for receipt by TV Households in the DMA in which the Licensed Community is located, as such DMA is identified on Exhibit A, and (ii) over the transmission facilities of any Acquired Station, except to the extent that, as of the date Affiliate notifies Network in writing of its binding agreement to acquire such Acquired Station, (A) another Broadcast Television station in the same DMA as the Acquired Station has exclusive rights to broadcast the Service, or (B) the Acquired Station is obligated to broadcast other material that precludes it from also carrying the Service. Affiliate shall telecast the Service from each Station’s origination transmitter and antenna for free over-the-air television reception, and by other customary means used by each Station to transmit its signal in its DMA ( _e.g_ ., FCC-licensed translators and fiber or microwave connections to MVPDs). Notwithstanding the foregoing, Affiliate shall have the right to authorize, and shall use reasonable efforts to obtain, carriage of the Service’s signal by MVPDs that retransmit digital Broadcast Television signals in the DMA of each Station that transmits the Service, which Service signal shall be transmitted by Affiliate together with the Primary Feed. Affiliate’s failure to obtain such carriage by any MVPD shall not be deemed a breach of this Agreement. Affiliate shall endeavor to secure carriage of the Service by MVPDs on the most highly penetrated level of digital service. Further, Affiliate shall have the right to authorize carriage of the Service’s signal on a nonexclusive basis by MVPDs that retransmit a Station’s Primary Feed outside the Station’s DMA, and that are carrying the Station’s analog signal as of the date of this Agreement. Notwithstanding the provisions of the preceding sentence, (1) Affiliate shall not authorize an MVPD to deliver the Service to subscribers outside the Station’s DMA in areas in which the Station, pursuant to FCC rules, is not “significantly viewed,” if the MVPD receives the Station’s signal via satellite, and (2) any agreement by Affiliate for out-of-DMA carriage of the Service shall require that the MVPD’s authorization from Affiliate to carry the Service terminate upon the initial overthe-air transmission of the Service by a Broadcast Television station whose Licensed Community is located within the DMA of the pertinent MVPD system if such station has exclusive rights to broadcast the Service in such DMA. Network shall provide Affiliate with at least 45 days’ advance written notice of such Broadcast Television’s station’s initial over-the-air transmission of the Service and Affiliate shall provide such notice to the pertinent MVPD. In the event Affiliate owns more than one Station in any DMA (a “Duopoly Market”), then Affiliate, at its option, shall have the right to determine which of its Stations in such DMA shall broadcast the Service; it being understood that Affiliate shall have no obligation to broadcast the Service over more than one of its Stations in any particular DMA. 

3 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(b) Any Acquired Station that is transmitting the Service at the time of acquisition by Affiliate shall (subject to the provisions of the preceding paragraph concerning Duopoly Markets) continue to transmit the Service and become a “Station” hereunder. Any existing agreement between or among Network and any one or more third parties applicable to such Station for the transmission of the Service shall terminate and cease to be effective upon its acquisition by Affiliate. Any Acquired Station in a DMA that is not transmitting the Service at the time of acquisition by Affiliate shall likewise become a “Station” hereunder upon acquisition and shall commence transmitting the Service within one hundred eighty (180) days after the acquisition is consummated, unless, as provided in 3(a) above, (A) another Broadcast Television station in the same DMA as the Acquired Station has exclusive rights to broadcast the Service, or (B) the Acquired Station is obligated to broadcast other material that precludes it from also carrying the Service. If condition (A) or (B) applies, the Acquired Station shall have no obligations hereunder, and Network shall have the right to license the transmission of the Service to another Broadcast Television station in such DMA, including on an exclusive basis. Notwithstanding the foregoing, if condition (A) applies, unless the existing affiliate is a Charter Affiliate, Network shall give Affiliate at least six (6) months’ prior written notice of the impending expiration of an existing affiliate’s affiliation agreement and, upon such notice, Affiliate shall have the option to add the pertinent Acquired Station as a “Station” hereunder as of the date of expiration of the existing affiliate’s affiliation agreement, provided that Affiliate exercises such right in writing at least four (4) months prior to the expiration of the existing affiliate’s affiliation agreement. 

(c) Except as expressly provided in Section 3(a), Affiliate shall not have the right (i) to subdistribute or otherwise sublicense the Service, or (ii) to transmit or otherwise distribute the Service by any technology (other than Broadcast Television), or on an interactive, timedelayed, “video-on-demand” or similar basis. For purposes hereof, “video-on-demand” means the transmission of a television signal by means of a point-to-point distribution system containing audiovisual programming chosen by a viewer for reception on a viewer’s television receiver, where the scheduling of the exhibition of the programming is not predetermined by the distributor, but rather is at the viewer’s discretion. 

(d) Except as expressly provided in Sections 3(a) and 3(b) and this Section 3(d), Network shall not have the right to distribute or otherwise license the Service for reception in a Station’s DMA, including distributing the Service directly through an MVPD in a Station’s DMA, other than through this license to Affiliate. Without limiting the generality of the preceding sentence, Network shall not distribute or authorize third parties to distribute the Service to subscribers by any technology (other than Broadcast Television and transmission by an MVPD), on an interactive, time-delayed (other than multiple time-zone feeds of the Service), “video-on-demand” or similar basis, as an audio-only service ( _e.g._ , radio) or over the Internet. For purposes of clarification, a promotional or marketing “stunt” simulcasting a live or special event, or brief excerpts of the Service made available on a non-subscription basis for promotional purposes shall not be prohibited by this Section 3(d) or any other provision herein. 

4 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(e) Network hereby grants Affiliate during the Term a royalty-free, fully paid up, non-transferable, non-exclusive license to use the Marks (as defined in Section 8(e)) in any advertising and promotional materials undertaken in connection with Affiliate’s transmission of the Service, provided that such use complies with the terms and conditions of Section 8(e). 

(f) Upon execution of this Agreement, Affiliate shall promptly complete and deliver to Network a notice of launch (in the form attached hereto in Exhibit B) for each Station (“Launch Notice”) and subsequently launch the Service on each Station listed on Exhibit A (subject to the provisions of 3(a) above concerning Duopoly Markets) no later than the Launch Date set forth opposite each Station on Exhibit A (for each Station, the “Launch Date”). In addition, Affiliate shall promptly complete a Launch Notice for any Acquired Station that is subsequently added to this Agreement. 

(g) Each Station, by the terms of this contract, shall be entitled to invoke the protection against duplication of Service programming imported under the compulsory copyright license as provided in Sections 76.101 and 76.123 of the FCC Rules. 

(h) Each Station transmitting the Service shall have the right to broadcast the Service on its Primary Feed, in addition to its broadcasts under Section 3(a). Such broadcasts shall be subject to all terms and conditions of this Agreement, including Sections 4(e) and 8(c). 

# 4.CONTENT OF THE SERVICE: 

(a) Content. Throughout the Term, the Service shall be a professionally produced, advertiser-supported television service with programming consisting of music videos, occasional programs discussing, reviewing and/or relating to music and concerts, related interstitial programming, promotional announcements and commercial announcements in the amounts specified herein, 24 hours a day, seven days a week, primarily targeted to reach adults ages 25-54. Subject to the preceding sentence and other provisions of this Agreement, the selection, scheduling, renewal, substitution and withdrawal of any content on the Service shall at all times remain within Network’s sole discretion and control. 

(b) Local Programming. Affiliate, at its own cost, shall be provided with thirty (30) minutes per week on the Service, on the same day and at the same time each week, as determined by Network in consultation with Affiliate, for the insertion of programming by Affiliate that is complementary to the Service (“Local Programming”), at Affiliate’s option. Service programming will be provided during this thirty (30) -minute period for Stations that do not insert Local Programming. It is anticipated that, at a future date to be mutually agreed upon by the parties, Affiliate shall have the right to expand such Local Programming to one (1) hour per week. Affiliate shall be solely responsible for the insertion on a timely basis of the Local Programming into the signal of the Service at the Stations transmitting the Service. Affiliate shall retain all revenue derived from sponsorship of the Local Programming. Affiliate shall apply the same broadcast standards to the Local Programming that it applies to each Station’s broadcasts over the Primary Feed. Without limiting the immediately preceding sentence, Local Programming shall not consist of or contain infomercials, home shopping or direct on air sales programming that are not directly related to music and concerts. 

5 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(c) Preemption. Affiliate shall retain the right to elect not to transmit any programming on the Service over the broadcast facilities of a Station if Affiliate reasonably believes that such programming is unsatisfactory or unsuitable or contrary to the public interest, or in order to substitute a program which, in Affiliate’s judgment, is of greater local or national importance. Affiliate agrees to notify Network either before or as soon as reasonably practicable after Affiliate exercises such right. 

(d) Children’s Programming. 

(i) Network will provide as part of the Service the minimum number of hours of “Core Programming,” as defined in 47 C.F.R. §73.671(c), as the same may be amended from time to time (“Core Children’s Programming”), and will comply with related requirements of the definition of “Core Programming” in order to enable Affiliate to comply with the “safe harbor” established by law or FCC regulation, solely with regard to the Service and as a result of the broadcast by the Stations of the Service on each such Station’s free, over-the-air, multicast feed. 

(ii) Network represents and warrants that if it supplies to Affiliate any programming produced primarily for children 12 years old or younger, such programming shall comply with the FCC’s commercial limits, including 47 C.F.R. §73.670, as the same may be amended from time to time, including limits on the amount of commercial matter and the prohibitions on host-selling, programlength commercials and the display of website addresses. 

(iii) At the end of each calendar quarter, Network will provide to Affiliate a copy of the Service’s schedule of Core Children’s Programming planned for the following calendar quarter, together with a certification indicating the amount of Core Children’s Programming made available to Affiliate during the preceding quarter and certifying that any programming produced primarily for children 12 years old or younger, as provided by Network, complied with the FCC’s rules. Network will provide copies of program logs or other documentation substantiating the amount of Core Children’s Programming or the amount of commercial matter in any Network program or program segment subject to the commercial limits, promptly upon request by Affiliate. 

(e) Advertising. Except for the Local Advertising and advertising broadcast in Local Programming, Network shall have the exclusive right and authority to sell all of the advertising on the Service and shall share a portion of Network’s Advertising Revenue generated from such sales with Affiliate in accordance with the terms of this Agreement. A Station will not be obligated to broadcast advertising that does not comply with the Station’s generally applicable broadcast standards. Network and Affiliate will cooperate in a good-faith effort to ensure that all Network advertising meets Stations’ broadcast standards. Without limiting the generality of the foregoing sentence, Network will not accept political or controversial-issue advertising, or advertising promoting distilled spirits or gambling, without Affiliate’s prior written approval. 

(f) Program Service Information. Network must provide to a reputable program information services entity a program schedule for 

the Service. 

6 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(g) Closed Captioning; Program Ratings. Network shall provide full-time closed captioning for the Service in all programming and at all times for which captioning is required by applicable law as applied to the Service. Network also shall display and encode program ratings for the Service using the industry-standard “V-chip” ratings system. 

# 5.DELIVERY AND DISTRIBUTION OF THE SERVICE: 

(a) During the Term, Network, at its expense, shall deliver a 24 hours per day, 7 days per week signal of the Service by transmitting it via AMC-3 or another domestic satellite commonly used for transmission of television programming to Broadcast Television stations. The signal of the Service, including any program-related data and enhancements, shall be contained in no more than a 5.0 megabits-per-second (“mbps”) stream of data and shall consist of a resolution of no less than 480 x 720i. Network’s failure, for reasons other than force majeure, to deliver a signal meeting the requirements of this Section 5(a) for more than twelve (12) hours in any consecutive thirty (30) day period without the written consent of Affiliate shall constitute a material breach of this Agreement, not subject to the cure provisions of Section 10(d); provided, however that Affiliate shall provide Network with notice of each event in which Network fails to deliver a signal meeting the requirements of this Section 5(a) as soon as reasonably practicable. 

(b) Exhibit C sets forth the specific equipment necessary for each Station to receive the signal of the Service (the “Receiving <u>Equipment”). At Affiliate’s option, Network shall furnish and install, at its expense, or reimburse Affiliate for its cost of furnishing and installing, the</u> Receiving Equipment to each Station that transmits the Service, provided that the Receiving Equipment for all of the Stations initially listed on <u>Exhibit A shall not exceed, in the aggregate, one hundred twenty-five thousand dollars ($125,000.00) (the “Equipment Reimbursement Cap”). At</u> Affiliate’s option, Network also shall furnish and install, or reimburse Affiliate for its cost of furnishing and installing, Receiving Equipment for any Acquired Station not transmitting the Service at the time of acquisition by Affiliate, at a cost not to exceed three thousand five hundred dollars ($3,500.00). Affiliate, at its expense, shall furnish all other equipment and facilities necessary for the receipt of the satellite transmission of the signal of the Service and the delivery of such signal to TV Households in each Station’s DMA. In addition, each Station shall be responsible, at its sole expense, for installing, maintaining or repairing the Receiving Equipment during the Term. Affiliate shall cause each of the Stations to maintain and repair the Receiving Equipment in good working condition, at its sole cost, as necessary and appropriate to maintain the ability of the Receiving Equipment to receive the signal of the Service from its initial satellite and transponder without interruption during the Term. If Network changes the satellite, transponder or encryption method used to transmit the Service and if the Receiving Equipment or other existing equipment will not be suitable for receiving the Service after the changes are implemented, with respect to such Station(s), Network agrees to furnish and install at its expense, or reimburse Affiliate for its reasonable cost of furnishing and installing, Receiving Equipment suitable for receiving the Service after the changes are implemented, without regard to the Equipment Reimbursement Cap; provided, however, that with respect to new equipment made necessary by a satellite, transponder or encryption method change, which equipment may be used to receive the signals of other television services carried by such Station, Network shall be obligated to reimburse Affiliate only for Network’s pro-rata share of the cost of such equipment (based on the total number of television services being received by such affected System and utilizing such new equipment within ninety (90) days of the effective date of such change). 

7 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(c) Each Station transmitting the Service shall transmit a good-quality video and audio signal of the Service, but in no event shall such Station be required to deliver a signal of a technical quality higher than the technical quality of the video and audio signal of the Service as delivered by Network hereunder. 

(d) Each Station agrees to transmit the Service on a full-time basis 24 hours per day, 7 days per week, except in cases of force majeure, emergency broadcasts, when a Station’s Primary Feed is not being transmitted, as provided in 4(c) above, or when a Station must stop broadcasting for maintenance or repairs. Each Station will provide Network with up to 5.0 mbps, but, at all times, not less than 2.0 mbps, for this purpose, except as required in infrequent and exceptional circumstances resulting from a Station’s carriage of the primary television network with which such Station is affiliated with regard to its Primary Feed ( _e.g._ , ABC, CBS, NBC and Fox). Except for a Station’s Local Advertising Time and Local Programming, station identification messages, and as except provided in 4(c) and 4(e) above, each Station shall transmit the Service without alteration, editing or delay. 

(e)  Network agrees to transmit SCTE 35-compliant DPI commands within the Service that will trigger insertion of Local Advertising and rejoin commands to signal the return to Network programming. Network also will deliver a separate set of SCTE 35-compliant commands to trigger local insertion and removal of station identification messages on the hour, and station logos before and after commercial breaks. To ensure clean switching, Network will ensure that switch commands occur coincident with transmission of an “I”-frame from the network MPEG 2 encoder. 

(f) Each Station that transmits the Service may superimpose over the programming on the Service a transparent station identification logo/“bug” that does not materially interfere with the Service or any graphics or other data therein. 

(g) Affiliate and each Station shall take the same security measures to prevent the unauthorized or otherwise unlawful copying or taping of the Service (or any portion thereof) by others as it takes to protect the Primary Feed transmitted by such Station. Network acknowledges that Affiliate and the Stations do not, as of the Effective Date, take any such security measures. 

# 6.NO FEES; REVENUE SHARE: 

(a) Neither Affiliate nor any Station shall pay any fees to Network for any rights granted under this Agreement. 

(b) In consideration of the terms and conditions set forth herein, Network shall pay Affiliate (i) the Affiliate Advertising Share, and (ii) the Affiliate Transactional Share, each as provided in Exhibit D. 

# 7.REPORTS; AUDITS: 

(a) Affiliate shall promptly notify Network in writing of any MVPD that has agreed to retransmit the Service. Network and Affiliate thereafter shall cooperate in an effort to secure the MVPD’s agreement to provide to Network and Affiliate, within thirty (30) days following each calendar quarter during the Term, a certified report stating the number of households that receive the Service from such MVPD (“Digital Cable <u>Subscriber Households”) in the DMA of a Station on average over such quarter (“Report”). If an MVPD fails to submit a Report, Network and</u> Affiliate shall estimate the number of Digital Cable Subscriber Households receiving the Service pursuant to paragraph I.1. of Exhibit D. 

8 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(b) Network shall submit to Affiliate, within forty-five (45) days of the end of each calendar quarter during the Term, a statement reporting for such calendar quarter the following information on a Station-by-Station basis: (i) Network’s Advertising Revenue, (ii) the Affiliate Advertising Share, (iii) Network’s Transactional Revenue, (iv) the average number of households receiving the Service through each MVPD in each DMA served by a Station, as calculated herein, and (v) the Affiliate Transactional Share. If this Agreement terminates on any date other than at the end of a calendar quarter, Network shall supply such statement as of the date of termination, within forty-five (45) days thereafter, and this obligation shall survive the termination of this Agreement until Affiliate receives such statement. 

(c) Affiliate shall submit to Network, within forty-five (45) days of the end of each calendar quarter, a report on behalf of each Station with respect to the Promotional Spots aired by each Station during such calendar quarter, setting forth the date and time each such Promotional Spot aired on the Primary Feed. 

# (d) Audit. 

(i) During the Term and for one (1) year thereafter, Network shall maintain accurate and complete books and records in accordance with generally accepted accounting principles and practices that shall contain sufficient information to enable an auditor to verify, for the period under audit, Network’s Advertising Revenue, Network’s Transactional Revenue, the Affiliate Advertising Share, the Affiliate Transactional Share and the accuracy of the amounts paid by Network to Affiliate hereunder, including under <u>Exhibit D (collectively, the “Revenue Share Records”). Upon not less than thirty (30) days’ prior written notice and not more than</u> once in any calendar year, Affiliate shall have the right, at its sole cost and expense, during the Term and for one (1) year thereafter, to examine during normal business hours the books and records of Network for up to the prior calendar year and the then-current calendar year solely to the extent reasonably necessary to verify the Revenue Share Records. 

(ii) Any audit conducted pursuant to this Section 7(d) shall be conducted by Affiliate’s corporate audit staff or an independent auditing firm designated by Affiliate (in each case, an “Auditor”). Any such audit shall be subject to the provisions of this Section 7(d) and the confidentiality provisions of Section 12, and the Auditor shall execute, in advance, a confidentiality agreement that obligates it to maintain the confidentiality of the terms of this Agreement and the information acquired during the course of the audit. Any officer, employee, consultant or agent of Affiliate that has access to an audit report (who shall be limited to those who are members of Affiliate’s corporate audit staff and have a specific need to know the contents thereof) shall also execute a confidentiality agreement consistent with the prior sentence. 

9 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(iii) Network and Affiliate shall use good faith efforts to resolve any dispute arising from an audit conducted pursuant to this Section 7(d). Any litigation by Affiliate with respect to amounts owing by Network in respect of an audit must be brought within one (1) year after the Auditor completes its on-site review at Network’s offices, or Affiliate will be deemed to have waived its right, whether known or unknown, to collect any shortfalls from Network for the period(s) audited; provided, however, that such limitation shall not apply to intentional misconduct by Network or its agents or employees. 

# 8.PROMOTION; AFFILIATE ADVERTISING: 

(a) Affiliate shall actively promote the Service consistent with its business judgment, including the broadcast by each Station transmitting the Service of an average of at least ten (10) thirty (30)-second promotional announcements per week for the Service (“Promotional <u>Spots”) on the Station’s Primary Feed, including the Station’s analog signal for so long as the Station broadcasts an analog signal, on a run-of-</u> station basis, commencing no later than the first air date of the Service on the applicable Station. Affiliate will submit program listings for the Service to local print and on-screen guides. Additionally, Affiliate will provide a link to Network’s website ( _i.e.,_ URL www.thetubetv.com or any replacement or supplemental URL) on the websites of each of the Stations. 

(b) Network shall produce and deliver the Promotional Spots to each Station at least two (2) weeks prior to the first air date, and on a regular basis thereafter, in a format mutually agreed with Affiliate and in a broadcast-ready state. Affiliate or a Station also may prepare its own Promotional Spots and other promotional materials, which, if using any programming from the Service, must be approved in advance by Network, such approval not to be unreasonably withheld. Network and Affiliate agree to consult on a regular basis during the Term concerning the content of the Promotional Spots, promotional materials and on Network and Affiliate promotional strategies, and Affiliate shall cease airing particular Promotional Spots or using particular promotional materials upon the reasonable objection of Network to such Promotional Spots or the use of such promotional materials. 

(c) Network shall provide to each Station that transmits the Service for local advertising sales, public service announcements, newsbreaks, station-produced vignettes or promotion one (1) minute of commercial announcement time per hour (“Local Advertising”), normally at the same approximate time each hour of the broadcast day. Affiliate shall have the right to retain for itself all the proceeds derived from the sale of Local Advertising. Affiliate agrees not to sell commercial time to or for the benefit of direct competitors of the Service ( _e.g.,_ music video networks carried by MVPDs such as MTV, VH1 and Fuse). All Local Advertising shall comply with the pertinent Station’s generally applicable broadcast standards and Affiliate shall be solely responsible for all Local Advertising and all liabilities associated therewith, including insertion, trafficking, billing and collection activities relating to the Local Advertising and for the content of the material inserted into the Local Advertising. 

(d) Network, from time to time, may undertake marketing tests and surveys, rating polls and other research in connection with the Service. With respect to any tests, surveys or research that apply to any Station or DMA for which Network seeks Affiliate’s cooperation, Network shall notify Affiliate of the nature and scope of each such project and Affiliate, to the extent permitted by applicable law and agreements by which Affiliate or a Station is bound, shall cooperate in such research by rendering such assistance as Network may reasonably request and which Affiliate can reasonably provide without incurring any additional expense. Network shall, promptly following receipt, provide the full results of any such research to Affiliate, on a confidential basis, unless Network is prevented from doing so by a confidentiality agreement or applicable law. 

10 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(e) Affiliate acknowledges that the name and mark “ _The TUBE_ ” (and the names of certain programs that appear in the Service and any subsequently selected names or marks for the Service and accompanying websites) (collectively, the “Marks”) are the exclusive property of Network and its suppliers and that Affiliate has not and will not acquire any ownership thereof by reason of this Agreement. Provided they do not infringe the marks of Affiliate or an affiliate of Affiliate, Affiliate shall not directly or indirectly question, attack, contest or in any other manner impugn the validity of the Marks or Network’s rights in and to the Marks and shall reasonably cooperate with Network’s quality control, monitoring and inspection of the use of the Marks. Any and all goodwill arising from Affiliate’s use of the Marks shall inure solely to the benefit of Network. Affiliate shall submit to Network representative samples of Affiliate’s promotional materials mentioning or using the Marks (other than materials provided by Network to Affiliate, if any) and shall cease using the Marks in a particular manner upon the reasonable objection of Network to the use of the Marks in such manner. Uses of the Marks in routine promotional materials, such as program guides and program listings, shall be deemed approved unless Network specifically notifies Affiliate to the contrary. Network shall acquire no rights in any of Affiliate’s marks by virtue of this Agreement. 

# 9.WARRANTIES AND INDEMNITIES: 

(a) Network and Affiliate each represents and warrants to the other that (i) it is duly organized, validly existing and in good standing under the laws of the state under which it is organized; (ii) it has the power and authority to enter into this Agreement and to perform fully its obligations hereunder; (iii) it is under no contractual or other legal obligation that shall in any way interfere with its full, prompt and complete performance hereunder; (iv) the individual executing this Agreement on its behalf has the authority to do so; and (v) the obligations created by this Agreement, insofar as they purport to be binding on it, constitute legal, valid and binding obligations enforceable in accordance with their terms. 

(b) Network further represents and warrants to Affiliate that it holds all necessary rights and licenses in and to the materials transmitted to Affiliate as part of the Service and such rights and licenses are sufficient to permit the transmission of the Service in the DMA of each of the Stations as contemplated herein, without infringing the copyright or other rights of any person. 

(c) Affiliate further represents, warrants and covenants to Network that (i) it has the power and authority to cause each Station, including any Acquired Station, to perform fully its obligations hereunder; and (ii) it holds and will continue to hold all necessary rights and licenses (A) to operate the Stations and permit the broadcast of the Service in the DMA of each of the Stations and (B) to broadcast the Local Programming and Local Advertising as contemplated herein. 

11 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(d) Affiliate and Network shall each indemnify, defend and forever hold harmless the other, the other’s parent, subsidiary and affiliated companies and each of the other’s (and the other’s parent, subsidiary and affiliated companies’) respective present and former officers, shareholders, directors, employees, consultants, partners and agents (“Network Indemnitees” and “Affiliate Indemnitees,” respectively), against and from any and all Costs incurred as a result of third-party claims arising out of any breach of any term of this Agreement or of any warranty, covenant or representation contained herein. 

(e) Without limiting Section 9(d), Network shall indemnify, defend and forever hold harmless the Affiliate Indemnitees from and against any and all Costs arising directly or indirectly out of third-party claims (i) that the transmission by Affiliate of the Service as contemplated herein infringes the rights of any person, (ii) based on the content of the Service and any promotional material provided by Network to Affiliate (including the Promotional Spots), as furnished by Network and transmitted by Affiliate and each Station in accordance with the terms and conditions of this Agreement ( _i.e._ , not based upon any deletions, modifications or additions by Affiliate or any Station), including any claim that such content or material is obscene, indecent, libelous, or slanderous, or violates any right of privacy or publicity, copyright, trademark or any other proprietary, literary, or dramatic right of any person or any rule or regulation of the FCC, and (iii) relating to any contest, sweepstakes or other promotion conducted by Network. Affiliate shall, to like extent, indemnify, defend and forever hold harmless the Network Indemnitees for Costs arising directly or indirectly out of third-party claims relating to (A) any deletion, addition or other modification of content, programming or other material by Affiliate to the Service, including Local Advertising and Local Programming, (B) any editing or deletion of program or promotional material by Affiliate contrary to Network’s instructions, (C) Promotional Spots and/or other promotional materials prepared by Affiliate, and (D) any contest, sweepstakes or other promotion conducted by Affiliate in connection with Network and/or the Service. 

(f) A party claiming indemnity under this Section 9 must give the indemnifying party prompt notice of any claim, and the indemnifying party shall, unless the parties otherwise agree, assume the full defense of any claims to which its indemnity applies. The indemnified party, at the indemnifying party’s cost, will cooperate fully with the indemnifying party in the defense or settlement of any such claim. Subject to the foregoing, the indemnified party may participate in the defense, through counsel of its choice, at its own expense. 

(g) The representations, warranties and indemnities contained in this Section 9 shall continue throughout the Term and the indemnities shall survive the termination of this Agreement, regardless of the reason for such termination. 

(h) Network has procured, and shall maintain during the Term, at its sole expense, Commercial General Liability insurance at liability limits of not less than $1,000,000 each occurrence and $2,000,000 in the aggregate. Additionally, Network will procure on or before the Affiliate Launch Date, and shall maintain during the Term, at its sole expense, Errors and Omissions insurance that covers Network’s media activities at a liability limit of $1,000,000 in any one (1) policy period. Affiliate shall be named as an additional insured on the policies, and, prior to the Affiliate Launch Date, shall receive certificates evidencing such insurance, providing that such coverage will not be cancelled or materially changed except upon 30 days’ prior written notice to Affiliate. 

12 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

# 10.TERMINATION: 

(a) In addition to Network’s other rights to terminate this Agreement, Network may, by providing Affiliate with thirty (30) days’ prior notice, terminate this Agreement if Affiliate is in material breach of this Agreement, provided that Affiliate shall have thirty (30) days from Network’s notice specifying in detail the nature of such breach to cure such breach; provided, however, if such breach is confined to a single breach by a Station or group of Stations during the Term, then Network shall have the right to terminate this Agreement only as to such Station or Stations, but if Affiliate willfully and repeatedly materially breaches any of the material provisions of this Agreement, then Network, at its option, shall have the right to terminate this Agreement in its entirety or only as to such breaching Station or Stations. 

(b) Network retains the right at all times during the Term to discontinue its distribution of the Service in its entirety and to terminate this Agreement and all other affiliates’ agreements on at least ninety (90) days’ prior notice without any liability therefor to Affiliate, other than amounts payable hereunder which accrued prior to such termination, including amounts payable pursuant to Section 6(b) and Exhibit D. 

(c) In the event that a Station initially listed on Exhibit A does not launch the Service by the Launch Date as required by Section 3(f) other than as a result of a force majeure event pursuant to Section 13(e), Network shall have the right to terminate this Agreement only as to such Station, but if three (3) or more Stations initially listed on Exhibit A do not launch the Service by the pertinent Launch Date for each such Station as required by Section 3(f) for reasons other than force majeure, Network, at its option, shall have the right to terminate this Agreement in its entirety or only as to such Station or Stations. In the event that Network terminates this Agreement as to a particular Station or several Stations, or in its entirety pursuant to Sections 10(a) or (c), Affiliate shall, within thirty (30) days of termination, at its option either reimburse Network for the cost of all equipment or return such equipment related to such Station(s) that was paid for by Network pursuant to Section 5(b) herein. 

(d) In addition to Affiliate’s other rights to terminate this Agreement, Affiliate may, by providing Network with thirty (30) days’ prior notice, terminate this Agreement if Network is in material breach of this Agreement, provided that Network shall have thirty (30) days from its receipt of Affiliate’s written notice specifying in detail the nature of such breach to cure such breach; provided, however, if such breach is confined to a Station or group of Stations during the Term, then Affiliate shall have the right to terminate this Agreement only as to such Station or Stations, but if Network willfully and repeatedly materially breaches any of the material provisions of this Agreement, then Affiliate, at its option, shall have the right to terminate this Agreement in its entirety or only as to such breaching Station or Stations. 

(e) Notwithstanding anything to the contary in this Section 10, any breach involving failure to pay any amount due hereunder must be cured within ten (10) days after notice. A breach involving Network’s failure to pay an amount due to Affiliate pursuant to Section 6 above or Exhibit D hereto shall be deemed a breach as to Affiliate rather than a particular Station or Stations. 

13 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

11. <u>NOTICES</u> 

Any notice given under this Agreement shall be in writing, shall be sent postage prepaid by certified mail, return receipt requested, or by hand delivery, or by Federal Express or similar overnight delivery service, to the other party, at the following address (unless either party at any time or times designates another address for itself by notifying the other party pursuant to the provisions of this Section 11, in which case all notices to such party thereafter shall be given at its most recently so designated address): 

To Network: The TUBE Music Network, Inc. 1451 West Cypress Creek Road, Suite 300 Ft. Lauderdale, FL 33309 Attn: John W. Poling, CFO Facsimile Number: (954) 714-8500 cc: Les Garland, President and CEO Facsimile Number: (305) 861-9409 To Affiliate: Tribune Broadcasting Company 435 North Michigan Avenue Chicago, IL 60611 Attn: Gina Mazzaferri Facsimile Number: (312) 222-5981 cc: Charles J. Sennet Facsimile Number: (312) 222-4206 

Notices given by hand delivery shall be deemed received upon delivery to the addressee. Notices given by certified mail shall be deemed received on the date specified on the return receipt. Notices given by Federal Express or similar overnight delivery service shall be deemed received on the next business day following delivery of the notice to such service with instructions for overnight delivery. 

<u>CONFIDENTIALITY:</u> 12. 

Neither Affiliate nor Network shall disclose (whether orally or in writing, or by press release or otherwise) to any third party outside their respective companies (other than their respective officers, directors and employees, in their capacity as such, and their respective auditors, consultants, financial advisors, lenders, potential buyers or investors and attorneys; provided, however, that the disclosing party agrees to be responsible for any breach of the provisions of this Section 12 by any of such parties) the terms of this Agreement (other than the existence hereof) except: (a) to the Auditor as provided in Section 7(d); (b) to the extent necessary to comply with the valid order or compulsory process of an administrative agency or a court of competent jurisdiction, in which event the party making such disclosure shall so notify the other as promptly as practicable (and, if possible, prior to making such disclosure); (c) in accordance with the regulations of any securities exchange on which such party (or its parent company) is listed, or otherwise as required by law; (d) in order to enforce its rights pursuant to this Agreement; or (e) if mutually agreed by Affiliate and Network, in advance of such disclosure, in writing. This Section 12 shall survive the termination of this Agreement. The parties agree to issue a mutually agreeable press release concerning this Agreement upon execution of this Agreement. 

14 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

# 13.MISCELLANEOUS: 

(a) Assignment; Binding Effect; Reorganization. This Agreement shall be binding on the respective transferees and successors of the parties hereto, except that neither this Agreement nor either party’s rights or obligations hereunder shall be assigned or transferred by either party without the prior written consent of the other party. Affiliate agrees to use reasonable efforts to obtain the agreement of any proposed assignee or transferee that, upon consummation of the assignment or transfer of control of the FCC license for any Station, such assignee or transferee shall negotiate in good faith with Network for continued rights to broadcast the Service over the affected Station. It will not be a breach of this Agreement, and Affiliate will not be required to accept a lower price or different terms in a proposed acquisition, if the proposed assignee or transferee does not accept this condition. Affiliate agrees to give Network timely notice of the filing of an assignment or transfer of control application with the FCC. 

(b) Entire Agreement; Amendments; Waivers; Cumulative Remedies. This Agreement, including the Exhibits attached hereto, contains the entire understanding of the parties hereto and supersedes and abrogates all contemporaneous and prior understandings of the parties, whether written or oral, relating to the subject matter hereof. This Agreement may not be modified except in a writing executed by both parties hereto. No waiver of any breach of any provision hereof shall be or be deemed to be a waiver of any preceding or subsequent breach of the same or any other provision of this Agreement. The failure of Affiliate or Network to enforce or seek enforcement of the terms of this Agreement following any breach shall not be construed as a waiver of a subsequent breach of the same or any other terms of this Agreement. All remedies, whether at law, in equity or pursuant to this Agreement shall be cumulative. 

(c) Governing Law. The obligations of Affiliate and Network under this Agreement are subject to all applicable federal, state and local laws, rules and regulations, and this Agreement and all matters or issues collateral thereto shall be governed by the laws of the State of New York applicable to contracts to be entirely performed therein. 

(d) Relationship. Neither party shall be, or hold itself out as, the agent of the other or as joint venturers under this Agreement. Nothing contained herein shall be deemed to create, and the parties do not intend to create, any partnership, association, joint venture, fiduciary or agency relationship between Affiliate and Network, and neither party is authorized to or shall act toward third parties or the public in any manner which would indicate any such relationship with the other. 

(e) Force Majeure. Neither Affiliate nor Network shall have any rights against the other party hereto for the non-operation of facilities or the non-furnishing of the Service if such non-operation or non-furnishing is due to an act of God; inevitable accident; fire; weather; lockout; strike or other labor dispute; riot or civil commotion; action or inaction of government or governmental instrumentality (whether federal, state or local); failure of performance by a common or private carrier; material failure or unavailability in whole or in part of technical facilities, software or equipment which are material to the transmission of the Service; or other cause beyond either party’s reasonable control (financial inability is excepted). A party will have the right to terminate this Agreement as to the affected Station(s), by notice to the other, if the other party’s inability to perform continues for thirty (30) days or more; provided, that Network may not terminate this Agreement due to a Station’s failure to launch the Service for reasons specified solely in this Section 13(e) unless such Station is unable to launch the Service for ninety (90) days or more beyond the applicable Launch Date. 

15 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(f) No Inference Against Author. Network and Affiliate each acknowledge that this Agreement was fully negotiated by the parties and, therefore, no provision of this Agreement shall be interpreted against any party because such party or its legal representative drafted such provision. 

(g) No Third-Party Beneficiaries. The provisions of this Agreement are for the exclusive benefit of the parties hereto (including the Stations) and their permitted assigns, and no third party shall be a beneficiary of, or have any rights by virtue of, this Agreement. 

(h) Headings. The titles, headings of the sections and defined terms in this Agreement are for convenience only and shall not in any way affect the interpretation of this Agreement. Any reference in this Agreement to “Section” or an “Exhibit” shall, unless the context expressly requires otherwise, be a reference to “Section” in, or an “Exhibit” to, this Agreement. Forms of the word “include” mean “including without limitation;” and references to “hereunder,” “herein,” “hereof,” and the like, refer to this Agreement. 

(i) Non-Recourse. Notwithstanding anything contained in this Agreement to the contrary, it is expressly understood and agreed by the parties hereto that each and every representation, warranty, covenant, undertaking and agreement made in this Agreement was not made or intended to be made as a personal representation, undertaking, warranty, covenant, or agreement on the part of any individual, and any recourse, whether in common law, in equity, by statute or otherwise, against any individual is hereby forever waived and released. 

(j) LIMITATION OF LIABILITY. NOTWITHSTANDING ANY OTHER PROVISION IN THIS AGREEMENT TO THE CONTRARY, NEITHER PARTY SHALL BE LIABLE TO THE OTHER PARTY FOR INCIDENTAL, CONSEQUENTIAL, PUNITIVE OR SPECIAL DAMAGES (INCLUDING LOSS OF PROFITS OF REVENUES, OR DAMAGES TO OR LOSS OF PERSONAL PROPERTY) IN ANY CAUSE OF ACTION ARISING OUT OF, RELATED TO, OR IN CONNECTION WITH A DEFAULT UNDER OR A BREACH OF THIS AGREEMENT. 

(k) Taxes. Network shall not be liable for, and Affiliate shall pay and hold harmless Network from, any federal, state or local taxes, surcharges, levies or any other charges which are based upon revenues derived by operations of Affiliate or each Station. Neither Affiliate nor Station shall be liable for, and Network shall pay and hold Affiliate and each Station harmless from, any federal, state or local taxes, surcharges, levies or any other charges which are based upon revenues derived by operations of Network. 

16 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

(l) Right of First Refusal. In the event Network decides to offer any new television programming channels (the “New Channels”), then Affiliate shall have ninety (90) calendar days from Affiliate’s receipt of Network’s comprehensive business plan for such New Channels to determine whether Affiliate desires to enter into an agreement with respect to the New Channels. At the expiration of the ninety (90)-day period, Affiliate’s right of first refusal shall expire. If, during said ninety (90)-day period, Affiliate notifies Network in writing of its desire to add the New Channels to this Agreement, then both parties shall work diligently together and in good faith to enter into an agreement within ninety (90) days of such notice to include the terms and conditions pursuant to which the New Channels may be distributed by Affiliate. If, having used good faith diligent efforts, Affiliate and Network have failed to enter into such an agreement within such ninety (90)-day period, then neither party shall have an obligation to continue such negotiations or enter into an agreement with respect to the New Channels. 

(m) Matter Broadcast. Federal law and FCC regulations require Network to disclose to Affiliate, and the Stations to disclose to their audiences, the identity of any person or entity that has given anything of value to Network or anyone associated with the Service in exchange for the inclusion of a product, service, trademark, brand name, or other program material in the Service. Network agrees to disclose to Affiliate, in writing, the existence, source and nature of any payments or other consideration received in connection with the production of the Service. Such disclosure shall be made prior to the time such matter is broadcast, so that each Station can satisfy its disclosure obligations under federal law. Notwithstanding anything to the contrary herein, proper disclosure in the content of the Service will satisfy Network’s disclosure obligations to Affiliate under this Section 13(m), provided Network agrees to provide full details to Affiliate immediately upon request. 

(n) Counterparts. This Agreement may be executed in counterparts, each of which will have the full force and effect of a fullyexecuted original. This Agreement may be executed by each or either party by delivering signed signature pages thereof to the other party by facsimile. Any party delivering an executed counterpart of this Agreement by facsimile shall also deliver to the other party an original executed counterpart of this Agreement, but the failure to do so does not affect the validity, enforceability or binding effect of this Agreement. 

[ _Remainder of page intentionally left blank._ ] 

17 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

The parties hereto have executed this Agreement to be effective as of the Effective Date. 

**AFFILIATE: NETWORK:** TRIBUNE BROADCASTING COMPANY THE TUBE MUSIC NETWORK, INC. By: /s/ John E. Reardon By: /s/ Les Garland Title: President Title: President 

[Signature page: Charter Affiliate Affiliation Agreement by and between The TUBE Music Network, Inc. and Tribune Broadcasting Company] 

18 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

# **<u>EXHIBIT A</u>** 

To Affiliation Agreement By and Between 

Tribune Broadcasting Company and 

The TUBE Music Network, Inc. 

Dated as of March 6, 2006 

# **<u>STATION IDENTIFICATION</u>** 

|**DMA**|**Call**<br>**Letters**|**Street Address**|**Launch**<br>**Date**|
|---|---|---|---|
|New York|WPIX|220 E. 42nd St.,10th floor,New York,NY 10017|6/1/06|
|Los Angeles|KTLA|5800 Sunset Blvd.,Los Angeles,CA 90028|6/1/06|
|Chicago|WGN|2501 W. BradleyPl.,Chicago,IL 60618|7/1/06|
|Philadelphia|WPHL|5001 Wynnefield Ave.,Philadelphia,PA 19131|7/1/06|
|Boston|WLVI|75 MorrisseyBlvd.,Boston,MA 02138|6/1/06|
|Dallas-Fort Worth|KDAF|8001 John Carpenter Fwy.,Dallas,TX 75247|7/1/06|
|Washington,D.C.|WBDC|2121 Wisconsin Ave. N.W.,Washington,DC 20007|8/15/06|
|Atlanta|WATL|One Monroe Place,Atlanta,GA 30324|7/15/06|
|Houston|KHWB|7700 Westpark Dr.,Houston,TX 77063|7/15/06|
|Seattle-Tacoma|KCPQ<br>KTWB|1813 Westlake Ave. N., Seattle, WA 98109|7/15/06|
|Miami-Ft. Lauderdale|WBZL|2055 Lee St.,Hollywood,FL 33020|7/15/06|
|Denver|KWGN|6160 S. Wabash Way,Greenwood Village,CO 80111|6/1/06|
|Sacramento-Stockton-Modesto|KTXL|4655 Fruitridge Rd.,Sacramento,CA 95820|8/1/06|
|St. Louis|KPLR|2250 Ball Dr.,St. Louis,MO 63146|8/1/06|
|Portland,OR|KWBP|10255 S.W. Arctic Dr., Beaverton, OR 97005|6/15/06|
|Indianapolis|WXIN<br>WTTV<br>WTTK|6910 Network Pl., Indianapolis, IN 46278|6/15/06|
|San Diego|KSWB|7191 Engineer Rd.,San Diego,CA 92111|6/15/06|
|Hartford & New Haven|WTIC<br>WTXX|One Corporate Center, Hartford, CT 06123|8/15/06|
|Grand-Rapids-Kalamazoo-Battle Creek|WXMI|3117 Plaza Dr. N.E.,Grand Rapids,MI 49525|&bbsp;6/15/06|
|Harrisburg-Lancaster-Lebanon-York|WPMT|2005 S.Queen St.,York,PA 17403|7/1/06|
|Albany-Schenectady-Troy|WEWB|14 Corporate Woods Blvd.,Albany,NY 12211|8/1/06|



19 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

# **<u>EXHIBIT B</u>** 

To Affiliation Agreement By and Between 

Tribune Broadcasting Company and 

The TUBE Music Network, Inc. 

Dated as of March 6, 2006 

# **<u>LAUNCH NOTICE</u>** 

BROADCAST LAUNCH FORM 

STATION NAME: STATION GROUP OWNER: STATION MAILING ADDRESS: PHONE NUMBER: FAX NUMBER: GENERAL MANAGER: MARKETING CONTACT: ENGINEER PHONE (IF DIFFERENT): EMAIL ADDRESS: AREAS SERVED (PLEASE INCLUDE ZIP CODES): 

DMA: 

FILL OUT THE LINE BELOW FOR ONE EARTH STATION RECEIVE SITE (EACH ADDITIONAL SITE REQUIRES A SEPARATE FORM) 

Do you have an antenna capable of receiving a C band feed from AMC-3 Transponder 17 located at 87 degrees west? YES____ NO____ 

Do you have space for an additional antenna on your roof or in your antenna farm? YES____ NO____ Does this space have a good southern exposure looking at 95 degrees? YES____ NO____ Do you have the resources to install the antenna? YES____ NO____ STREET ADDRESS (Shipping Address): CITY/STATE/ZIP: COUNTY: **LAUNCH DATE: ______________ CHANNEL NUMBER: ______________** SIGNATURE: TITLE: DATE: 

# **Email COMPLETED FORM to linefinder_1999@yahoo.com** 

20 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

# **<u>EXHIBIT C</u>** 

To Affiliation Agreement By and Between 

Tribune Broadcasting Company and 

The TUBE Music Network, Inc. 

Dated as of March 6, 2006 

# **<u>RECEIVING EQUIPMENT</u>** 

- C-Band Antenna equipped with appropriate feed assembly and 45-degree digitally compatible LNB 

- 150 Feet of RG6 Coaxial Cable 

- Integrated receiver/decoder, including MPEG 2 standard definition decoder that can decode an AC3 encoded audio stream at 384 kbps (the audio stream to be delivered by Network), and an unscrambled DVB-compliant ASI output. 

- De-icing equipment and/or radomes at the following Stations (and any later-acquired stations where climatologically WXIN/WTTV/WTTK, Indianapolis; WPHL-TV, Philadelphia; WGN-TV, Chicago; WXMI, Grand Rapids. 

21 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

**_Execution Copy_** 

# **<u>EXHIBIT D</u>** 

To Affiliation Agreement By and Between 

Tribune Broadcasting Company and 

The TUBE Music Network, Inc. 

Dated as of March 6, 2006 

# **<u>REVENUE SHARE</u>** 

Commencing on the Affiliate Launch Date and thereafter throughout the Term, Network shall pay to Affiliate the following amounts: 

I.Affiliate Advertising Share. 

- 1.Determining Affiliate Advertising Share. Commencing with the calendar quarter beginning on April 1, 2006 and for each calendar quarter thereafter during the Term, Network shall pay to Affiliate the Affiliate Advertising Share. For purposes hereof, the “Affiliate Advertising Share” shall be determined by multiplying fifteen percent (15%) of Network’s Advertising Revenue for such calendar quarter by a fraction, the numerator of which is the total number of Digital Cable Subscriber Households in the DMA(s) of the Station(s) transmitting the Service pursuant to this Agreement, and the denominator of which is the total number of Digital Cable Subscriber Households in all of the DMAs in which Network has a broadcast television station affiliate that is transmitting the Service. If a Station commences transmitting the Service on other than the first day of a calendar quarter, then the Affiliate Advertising Share for such quarter shall be further prorated based on the number of days in such quarter that such Station transmitted the Service. For purposes of this Exhibit D, The number of Digital Cable Subscriber Households shall be determined by the certified report supplied by each MVPD distributing the service, described in Section 7(a) of the body of this Agreement. In the event that such report is not received by Network with respect to each and every MVPD that carries the Service, then, for purposes of this Exhibit D, the number of Digital Cable Subscriber Households shall be determined as follows: 

   - a.In the event that the total number of linear digital video subscribers served by an MVPD that distributes the Service is not broken out by DMAs in such MVPD’s reported data, then, for purposes of this Exhibit D, the number of Digital Cable Subscriber Households for such non-reporting MVPD shall be equal to the product of (x) the number of TV Households receiving linear video services from such MVPD’s systems that carry the Service in the pertinent DMA as set forth in a Nielsen report such as FOCUS multiplied by (y) the National Digital Cable Penetration Percentage most recently reported by such MVPD. The “National Digital Cable Penetration Percentage” shall be equal to the quotient of (i) the total number of subscribers to linear digital video services as most recently publicly reported by such MVPD, divided by (ii) the total number of TV Households receiving linear video services from such MVPD as most recently publicly reported by such MVPD. 

22 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

   - <sup>b. In the event that a particular MVPD does not report its total number of subscribers to linear digital video services and</sup> total number of TV Households receiving linear video services, then, for purposes of this Exhibit D, the number of Digital Cable Subscriber Households for such non-reporting MVPD shall be equal to the product of (x) the number of TV Households receiving linear video services served by such MVPD’s systems that carry the Service as set forth in a Nielsen report such as FOCUS multiplied by (y) a national digital cable penetration estimate from Kagan Research, LLC. 

   - <sup>c. In the event that a more accurate independent publicly available source for determining the number of television</sup> households that receive the Service through a subscription cable service hereafter becomes available, the parties may mutually agree to use such source in lieu of the foregoing. 

- 2.Payment. The Affiliate Advertising Share, if any, shall be payable quarterly and shall be due no later than forty-five (45) days following the end of each calendar quarter for which a payment is due. If this Agreement is terminated during a calendar quarter, the amount payable shall be determined as of the termination date. 

II.Affiliate Transactional Share. 

- 1.Determining Affiliate Transactional Share. Commencing with the calendar quarter beginning on April 1, 2006 and for each calendar quarter thereafter during the Term, Network shall pay to Affiliate the Affiliate Transactional Share. For purposes hereof, the “Affiliate Transactional Share” means fifteen percent (15%) of Network’s Transactional Revenue for the pertinent calendar quarter. 

- 2.Payment. The Affiliate Transactional Share, if any, shall be payable quarterly and shall be due no later than forty-five (45) days following the end of each calendar quarter for which a payment is due. If this Agreement is terminated during a calendar quarter, the amount payable shall be determined as of the termination date. 

23 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

# **<u>EXHIBIT E</u>** 

To Affiliation Agreement By and Between 

Tribune Broadcasting Company and 

The TUBE Music Network, Inc. 

Dated as of March 6, 2006 

# **<u>ADDITIONAL TERMS AND CONDITIONS</u>** 

# **<u>Music Rights and Copyright Indemnification</u>** 

Without limiting Network’s indemnification obligations as set forth in the body of this Agreement: 

Network agrees to indemnify the Affiliate Indemnitees against any and all Costs arising out of any (i) third-party claims that Network’s music performance rights licenses with ASCAP, BMI and SESAC (or directly with the applicable composer(s) and publisher(s)) do not cover music performances through to the viewers of the Service; and (ii) written agreement between Affiliate and an MVPD for the retransmission of the Service (together with the Primary Feed as provided in Section 3(a) of the body of the Agreement) solely within the Station’s DMA, or where the Station’s signal is deemed “significantly viewed” pursuant to FCC rules, pursuant to which Affiliate is obligated to indemnify such MVPD against any Incremental Copyright Cost (as defined below) resulting directly from the retransmission of the Service by such MVPD in the Station’s DMA. For purposes hereof, “Incremental Copyright Cost” shall mean the difference, if any, between (A) the copyright royalties that would be payable by the MVPD in the Station’s DMA without carriage of the Service, and (B) the copyright royalties that would be payable by such MVPD in such DMA with the carriage of the Service. Network hereby authorizes Affiliate to enter into such an agreement if, in Affiliate’s reasonable and good faith judgment, such an agreement is necessary to obtain an MVPD’s consent to carry the Service. For purposes of clarification, ASCAP, BMI and SESAC are and shall be considered “third parties.” Network represents and warrants that it has and throughout the Term will have a valid throughto-the-viewer music performance rights license with ASCAP and BMI (and any other society that may license such rights for music contained in the Service) (or directly with the applicable composer(s) and publisher(s)) covering all of the music contained in the Service. Network has commenced negotiations for a through-to-the-viewer music performance rights license with SESAC and expects to attain such license within a reasonable period of time. 

24 

Source: TUBE MEDIA CORP., 8-K, 3/10/2006 

