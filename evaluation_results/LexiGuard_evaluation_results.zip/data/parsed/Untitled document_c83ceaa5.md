# **MASTER JOINT VENTURE AND REVENUE SHARING AGREEMENT** 

**Effective Date:** September 1, 2026 

**Reference ID:** JV-2026-993-OMEGA 

This Master Joint Venture and Revenue Sharing Agreement ("Agreement") is entered into by and among: 

1. **Helios Aerospace Industries, Inc.** , a Delaware corporation ("Helios" or "Lead Partner"), 2. **Nova Dynamics LLC** , a Texas limited liability company ("Nova" or "Manufacturing Partner"), and 

3. **Quantum Logistics Group** , a British Columbia corporation ("Quantum" or "Distribution Partner"). 

Collectively, Helios, Nova, and Quantum shall be referred to as the "Parties" and individually as a "Party". 

## **SECTION 1: DEFINITIONS** 

- **1.1 "Gross Revenue"** means all income generated from the sale of the Joint Venture product (the "Drone System") before any deductions. 

- **1.2 "Net Profit"** means Gross Revenue minus allowable manufacturing and distribution costs as defined in Section 4.2. 

- **1.3 "Force Majeure"** means acts of God, strikes, or regulatory embargoes that delay production by more than thirty (30) days. 

## **SECTION 2: ROLES AND OBLIGATIONS** 

- **2.1 Lead Partner Duties:** Helios shall provide all proprietary software, blueprints, and initial capital of $5,000,000 to fund the Joint Venture. 

- **2.2 Manufacturing Partner Duties:** Nova shall physically manufacture the Drone Systems. Nova must produce a minimum of 10,000 units per quarter. 

- **2.3 Distribution Partner Duties:** Quantum shall handle international shipping, customs compliance, and warehousing. 

## **SECTION 3: PENALTIES FOR DELAY** 

- **3.1 General Manufacturing Penalty:** If the Manufacturing Partner fails to deliver the 10,000 quarterly units required under Section 2.2, they shall be subject to a penalty of $50 per undelivered unit. 

- **3.2 General Distribution Penalty:** If the Distribution Partner fails to clear customs for a shipment within fourteen (14) days of receipt from Nova, Quantum shall pay a flat penalty of $25,000 per delayed shipment. 

- **3.3 The "Helios Software" Exception:** Notwithstanding anything to the contrary in Sections 3.1 and 3.2, no penalties shall be levied against Nova or Quantum if the delay is directly caused by Helios failing to provide the mandatory software updates required for the Drone System's operation. 

## **SECTION 4: FINANCIAL TERMS AND REVENUE SHARING** 

- **4.1 Revenue Split:** Provided no penalties are active under Section 3, the Net Profit shall be distributed on the 15th of every month according to the following schedule: 

|**Partner**|**Role**|**Equity Share**|**Net Profit Allocation**|
|---|---|---|---|
|Helios Aerospace|Lead|50%|45%|
|Nova Dynamics|Manufacturing|30%|35%|
|Quantum Logistics|Distribution|20%|20%|



● 

   - **4.2 Allowable Deductions:** Nova may deduct up to $150 per unit for raw materials. Quantum may deduct up to $45 per unit for international freight. Any costs exceeding these caps must be absorbed by the respective Party. 

- **4.3 Profit Forfeiture:** If any Party triggers a penalty under Section 3, their Net Profit Allocation for that specific calendar month shall be reduced by 10%, with the forfeited amount redistributed equally among the non-breaching Parties. 

## **SECTION 5: INTELLECTUAL PROPERTY** 

- **5.1 Background IP:** Helios retains 100% ownership of all software and blueprints provided under Section 2.1. 

- **5.2 Developed IP:** Any new hardware improvements discovered by Nova during the manufacturing process shall be jointly owned by Helios and Nova on a 50/50 basis. Quantum shall have no claim to Developed IP. 

## **SECTION 6: TERMINATION AND WITHDRAWAL** 

- **6.1 Voluntary Withdrawal:** Any Party may withdraw from this Joint Venture by providing ninety (90) days written notice. 

- **6.2 Buyout Clause:** If Nova withdraws, Helios has the first right of refusal to purchase Nova's manufacturing equipment dedicated to this Joint Venture for exactly $2,500,000. 

- **6.3 Immediate Termination for Cause:** This Agreement may be terminated immediately by the Lead Partner if either Nova or Quantum commits material fraud, files for bankruptcy, or violates the customs compliance laws of the United States. 

## **SECTION 7: GOVERNING LAW** 

- **7.1 Jurisdiction:** This Agreement shall be governed by the laws of the State of New York. 

- **7.2 Dispute Resolution:** All disputes shall be resolved via binding arbitration in Manhattan, New York, with costs split equally among all participating Parties. 

