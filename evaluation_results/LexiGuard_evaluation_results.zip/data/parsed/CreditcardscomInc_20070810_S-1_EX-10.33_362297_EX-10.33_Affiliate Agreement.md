**Exhibit 10.33** 

Last Updated: April 6, 2007 

# CHASE AFFILIATE AGREEMENT 

THIS AGREEMENT sets forth the terms and conditions agreed to between Chase Bank USA, N.A. (?Chase?) and you as an “Affiliate” in the Chase Affiliate Program (the “Affiliate Program”). Once accepted into the Affiliate Program, an Affiliate can establish links from the Affiliate’s Website to [Chase.com]. Chase will pay Affiliate a fee for each approved credit card account that originates from a link in Affiliate’s Website. 

THIS IS A LEGAL AND CONTRACTUALLY BINDING AGREEMENT BETWEEN AFFILIATE AND CHASE. TO APPLY TO THE AFFILIATE PROGRAM, YOU MUST COMPLETE AND SUBMIT THE AFFILIATE REGISTRATION FORM AND CLICK ON THE “AGREE” BUTTON BELOW TO INDICATE YOUR WILLINGNESS TO BE BOUND TO CHASE BY THIS AGREEMENT. THIS AGREEMENT WILL TAKE EFFECT IF AND WHEN CHASE REVIEWS AND ACCEPTS YOUR REGISTRATION FORM AND PROVIDES YOU NOTICE OF ACCEPTANCE. BY SUBMITTING YOUR REGISTRATION FORM, AFFILIATE CERTIFIES THAT YOU HAVE READ AND UNDERSTAND THE TERMS SET FORTH BELOW, AND THAT YOU ARE AUTHORIZED TO SUBMIT THIS REGISTRATION FORM BY THE NAMED AFFILIATE. 

In connection with your participation in the Affiliate Program, Affiliate and Chase agree as follows: 

1. Enrollment in the Affiliate Program; Restricted Content 

To enroll in the Affiliate Program, you must submit a complete “Affiliate Registration Form” via the Chase Affiliate Website: 

For new affiliates: https://ssl.linksynergy.com/php-bin/reg/sregister.shtml?mid=2291 

For existing affiliates: http://www.linkshare.com/joinprograms?oid=87909 

Chase will evaluate your registration form and will notify you via e-mail of the acceptance or rejection of your registration form. Chase reserves, in its sole discretion, with or without reason, the right to accept or reject your registration into the Chase Affiliate Program, including but not limited to a determination that your site is unsuitable for or incompatible with the Affiliate Program based on the following criteria (collectively “Restricted Content”): 

- Incorporates images or content that is any way unlawful, offensive, profane, harmful, threatening, defamatory, obscene, harassing or racially, ethically or otherwise objectionable 

- Promote illegal activities, including gambling 

- Promotes or depicts sexually explicit, obscene or pornographic images 

- Promotes or depicts violence or hate speech 

- Promotes discrimination based on race, sex, religion, nationality, disability, sexual orientation or age 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

- Incorporates any materials which infringe or assist others to infringe on any copyright, trademark or other intellectual property rights 

- Contains or promotes politically sensitive or controversial issues 

Chase also reserves the right to terminate this Agreement in the event that any Restricted Content is incorporated on Affiliate’s site after acceptance of your registration form and the commencement of the term of this Agreement. Chase may also terminate this Agreement if your site is deemed unsuitable based on the criteria below: 

- Manipulates key word searches on portals 

- Misrepresents itself as a Chase Website by altering the visual “look and feel” of or text from Chase’s site, and/or engage in “framing” the Chase Website 

- Engages in domain squatting 

- Engages in spamming or unsolicited commercial e-mail 

- Engages in unauthorized telemarketing or remarketing of Chase Credit Card offers via telephone 

- Uses Chase products and services in the domain name, URL or URI, including, but not limited to, any combination of the following words: 

- JP 

- MORGAN 

- CHASE 

- MANHATTAN 

- AARP 

- AMAZON.COM 

- BALL STATE UNIVERSITY 

- BORDERS 

- BRITISH AIRWAYS 

- CASH PLUS 

- CHASE FREEDOM 

- CENTRAL MICHIGAN UNIVERSITY 

- CONTINENTAL 

- CORNELL UNIVERSITY 

- DISNEY 

- DUKE UNIVERSITY 

- FLEXIBLE REWARDS 

- FREE CASH 

- HARVARD COOP 

- HESS 

- HOME IMPROVEMENT 

- LEHIGH UNIVERSITY 

- LOUISIANA STATE UNIVERSITY 

- MARATHON 

- MARRIOTT 

- MIAMI UNIVERSITY 

- OHIO UNIVERSITY 

- OVERSTOCK 

- PERFECT CARD 

- PRIORITY CLUB / HOLIDAY INN 

- SONY 

- SOUTHERN ILLINOIS UNIVERSITY 

- SPEEDWAY SUPER AMERICA 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

- STARBUCKS 

- SUBARU 

- TEMPLE UNIVERSITY 

- TOYS "R" US 

- TRAVEL PLUS 

- TRUMP 

- ULTIMATE REWARDS 

- UNITED 

- UNIVERSAL 

- UNIVERSITY OF ARIZONA ATHLETICS 

- UNIVERSITY OF CHICAGO 

- UNIVERSITY OF FLORIDA 

- UNIVERSITY OF HOUSTON 

- UNIVERSITY OF IDAHO 

- UNIVERSITY OF KENTUCKY 

- UNIVERSITY OF MARYLAND 

- UNIVERSITY OF MEMPHIS 

- UNIVERSITY OF MINNESOTA ATHLETICS 

- UNIVERSITY OF NOTRE DAME 

- UNIVERSITY OF OKLAHOMA 

- UNIVERSITY OF OREGON 

- UNIVERSITY OF SOUTH CAROLINA 

- UNIVERSITY OF TENNESSEE 

- UNIVERSITY OF VIRGINIA 

- UTAH STATE UNIVERSITY 

- VALUE MILES 

- VIRGINIA TECH APPROVED ACCOUNT 

- VOLKSWAGEN 

- WESTERN ILLINOIS UNIVERSITY 

- YALE UNIVERSTIY 

- Uses a proxy server or redirector server to proxy Chase web pages or web sites through your website, URL or URI 

- Otherwise violates intellectual property rights, including, without limitation, “scraping” text or images from Chase’s Website 

- Does not clearly state an online privacy policy to its visitors 

- Is based outside of the United States 

- Is otherwise considered offensive or inappropriate, at Chase’s discretion 

2. Affiliate Responsibilities: 

- Affiliate cannot use or implement creative that is not available through the LinkShare affiliate interface. 

- Affiliates may not harvest or collect personal information, or email addresses using the Chase brand without the written consent of Chase 

- If Affiliate manages a sub-affiliate network, upon Chase’s request, Affiliate shall promptly provide Chase with a current, written list identifying the sub-affiliates or other third parties associated. 

- Chase reserves the right to review and approve all sub-affiliate partners. 

- Chase shall only use the list for the sole purpose of administering the program and monitoring proper usage, and will not poach or contact subaffiliates directly. 

- Affiliates will not use the following product keyword search terms. (See Appendix) 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

- If Affiliate manages a sub-affiliate network, the Affiliate may not pay sub-affiliates or other partners higher referral fees than the lowest tier of the public offer ($55.00). 

• Affiliate is prohibited from (a) installing spyware on another person’s computer, (b) causing spyware to be installed on another person’s computer, or (c) using a context based triggering mechanism to display an advertisement that partially or wholly covers or obscures paid advertising or other content on an Internet website in a way that interferes with a user’s ability to view the Internet website. 

# 3. Referral Fee 

For each Approved Account (as defined in section 4 below) received through Affiliate’s site, Affiliate will earn a referral fee calculated in accordance with the schedule set forth below (“Commission”) paid monthly. 

- Tiered or flat commission based on private offer terms in the network. 

Chase reserves the right to alter above referral fees from time to time upon written notice to Affiliate of such change. 

# 4. Approved Account 

For purposes of determining Affiliate’s Commission, an “Approved Account” means any Chase credit card application that is: (i) submitted by any user who clicks on an e-mail, banner or any other advertising material from Affiliate’s Website; (ii) is approved by Chase; and (iii) is reported as approved by Chase to Affiliate. 

# 5.Term of this Agreement 

The term of this Agreement will commence on the date that the Affiliate Registration Form is approved by Chase and will end when terminated by either party. Either Affiliate or Chase may terminate this Agreement at any time, with or without cause, by giving the other party written or e-mail notice of termination. At the time of termination, any links to Chase’s Website must be removed immediately. Affiliate will continue to receive Commission payments for all Approved Accounts placed during the term of this Agreement. Notwithstanding the foregoing, Chase may 

terminate this Agreement if Affiliate does not comply with the terms and conditions herein. 

# 6. Links 

Affiliate agrees to place Chase’s links provided by Linkshare NetworkTM which manages the Affiliate Program (“Links”) on its Affiliate’s website. Affiliate is responsible for obtaining prior written approval from the Chase Affiliate manager or Linkshare Network to link any or all other sites owned or managed by the Affiliate, other than the site that was approved at the time of original registration. Affiliate may select or remove Links, at any time without prior approval from Chase. Affiliate is also responsible for removing and/or informing Chase of potential inactive or misdirected Links. Affiliate agrees to cooperate with Chase in establishing and maintaining Links. 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

# 7. Order Processing 

Chase will be solely responsible for processing each order placed by a customer from Affiliate’s Links. Customers may only use the Chase on-line application process to apply for a Chase credit card. “Customers” are defined herein as individuals who apply for Chase credit cards through a link in Affiliate’s Web site. Chase shall be responsible for administering application forms and related customer service. All of the rules, operating procedures and policies of Chase regarding customer orders and accounts will apply to orders received through the Links. Chase reserves the right to reject any credit card application in its sole discretion. 

# 8. Tracking of Sales 

Chase will be solely responsible for tracking Approved Accounts made to customers who follow Affiliate’s Links. Affiliate will be solely responsible for ensuring that the Links are formatted properly and maintained in a manner, which allows Chase to track such Approved Accounts. No Commission shall be paid if the Approved Account cannot be tracked by Chase’s system or if the customer accesses the Chase site through means other than the Links. Chase will provide Affiliate with statements of Approved Account activity at the time Commissions are paid. 

# 9. Terms and Conditions of Credit Cards 

Chase is solely responsible for determining the terms and conditions of the credit cards. The credit card offers may vary from time to time and are subject to change. Affiliate may not specify details regarding the Chase credit card on their Websites without the prior approval of Chase. 

# 10. Chase Customers 

Customers who apply for Chase credit cards through the Chase Affiliate Program are customers of Chase. Affiliate has no authority to make or accept any offer on behalf of Chase. All Chase policies regarding customer orders, including availability, pricing and problem resolution, will apply to these customers. Affiliate has no authority to make, and Chase is not responsible for, any representations made by Affiliate that contradict these policies. 

# 11. Product Descriptions 

Affiliate will only use credit card descriptions provided or approved in writing by Chase. 

# 12. Copyrighted Material 

Affiliate is solely responsible for ensuring that its reviews and articles obey all applicable copyright and other laws. Generally, Affiliate must have express permission to use another party’s copyrighted or other proprietary material. Chase is not responsible for Affiliate’s improper use of another party’s copyrighted or proprietary material. 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

# 13. Commercial Use 

This program is intended for commercial use only. Commissions are payable for Approved Accounts to third parties who access the Chase URL's (marketing pages) through the Links located on Affiliate’s sponsoring Web site. Affiliates who use this program to apply for credit cards for their own use are NOT in violation of this Agreement. 

# 14. Trademarks 

All Chase trademarks, trade names and service marks (collectively, the “Marks”) are the exclusive property of Chase. Notwithstanding anything set forth in this Agreement, Chase reserves full ownership of the Marks and the Licensed Materials (as defined below). All 

use of the Marks by Affiliate is limited solely to the use contemplated by this Agreement. All use of Chase Marks by Affiliate is subject to the prior written approval of Chase. 

# 15. Licenses and Use of the Chase Logos and Trademarks 

Chase grants Affiliate a non-exclusive, nontransferable, revocable right to (a) access the Chase site through the links solely in accordance with the terms of this Agreement and (b) solely in connection with such links, to use Chase’s logos, trade names, trademarks, and similar identifying material relating to Chase (collectively, the “Licensed Materials”), for the sole purpose of booking Chase products. Prior to using any of the Licensed Materials, Affiliate will submit to Chase for approval a draft of all proposed material that incorporates the Licensed Materials, together with a brief statement setting forth the proposed use of such materials and any other background or supporting material reasonably requested by Chase to allow Chase to make an informed judgment. All such materials shall be submitted to Chase at least seven (7) days prior to the date of first intended use. Chase will notify Affiliate of its approval or disapproval of such materials within five (5) business days of its receipt of all information required to be submitted. 

The approval or disapproval of such materials will be in Chase’s sole discretion. Any materials not receiving Chase’s specific written preliminary approval will be deemed disapproved. Affiliate may not alter, modify, or change the Licensed Materials in any way. Affiliate is only entitled to use the licensed materials to the extent that it is a member in good standing of the Chase Affiliate Program. Affiliate agrees not to use the Licensed Materials in any manner that is disparaging or that otherwise portrays Chase in a negative light. Chase may revoke Affiliate’s license at any time. 

# 16. Service Interruption 

Certain technical difficulties may, from time to time, result in service interruptions. Affiliate agrees not to hold Chase responsible for the consequences of such interruptions. 

# 17. Indemnification 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

Affiliate hereby agrees to indemnify, defend, and hold harmless Chase, its shareholders, officers, directors, employees, agents, affiliates and their respective directors, officers, employees and agents, successors and assigns, from and against any and all claims, demands, losses, liabilities, damages or expenses (including attorneys’ fees and costs) of any nature whatsoever incurred or suffered by Chase (collectively the “losses”), in so far as such losses (or actions in respect thereof) arise out of, are related to, or are based on (i) the breach of any representation, warranty, or covenant made by Affiliate herein; or (ii) any claim related to Affiliate’s site. 

# 18. Confidentiality 

Except as otherwise provided in this Agreement or with the consent of the other party hereto, each of the parties hereto agrees that all information including, without limitation, the terms of this Agreement, business and financial information, customer and vendor lists, and pricing and sales information, concerning Chase, Customer or Affiliate shall remain strictly confidential and secret and shall not be utilized, directly or indirectly, by such party for its own business purposes or for any other purpose except and solely to the extent necessary to exercise rights and perform obligations under this Agreement. The foregoing restrictions will not apply to information to the extent it (i) was known to the receiving party at the time of disclosure; (ii) has become publicly known through no wrongful act of the receiving party; (iii) has been rightfully received from a third party under no obligation to the disclosing party; (iv) has been disclosed by court order or as otherwise required by law if the receiving party has given the disclosing party a reasonable opportunity to contest or limit the scope of such required disclosure. 

# 19. Modification 

Chase reserves the right to change any and all of the terms and conditions in this Agreement, at any time and in its sole discretion, by posting a new agreement on its Website. Without limiting the generality of the foregoing, the amount of Commissions, the definition of Approved Accounts, and all other provisions of this Agreement are subject to change without notice other than posting such information on the Chase Website. IF ANY MODIFICATION IS UNACCEPTABLE TO AFFILIATE, THE ONLY RECOURSE IS TO TERMINATE THIS AGREEMENT. AFFILIATE’S CONTINUED PARTICIPATION IN THE AFFILIATE PROGRAM FOLLOWING CHASE’S POSTING OF A NEW AGREEMENT ON ITS WEB SITE WILL CONSTITUTE BINDING ACCEPTANCE OF THE CHANGE. 

# 20. Warranty Disclaimer 

Chase makes no warranties, representations or conditions with regard to the Chase Affiliate Program or any services provided hereunder, whether express or implied, arising by law or otherwise, INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT OR ANY IMPLIED WARRANTY ARISING OUT OF COURSE OF PERFORMANCE, COURSE OF DEALING OR USAGE OF TRADE. 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

# 21. Limitation of Damages 

Chase shall have no liability for any indirect, incidental, special or consequential damages or any loss of revenue or profits arising under or with respect to this Agreement or the Affiliate Program, regardless of whether Chase has been advised of the possibility of such damages. Further, Chase’s aggregate liability arising under or with respect to this Agreement or the Affiliate Program shall in no event exceed the total Commissions paid or payable by Chase to Affiliate under this 

Agreement. 

# 22. Independent Investigation 

AFFILIATE ACKNOWLEDGES THAT IT HAS READ THIS AGREEMENT, HAS HAD AN OPPORTUNITY TO CONSULT WITH ITS OWN LEGAL ADVISERS IF IT SO DESIRED, AND AGREES TO ALL ITS TERMS AND CONDITIONS. AFFILIATE AGREES THAT, IN INTERPRETING THIS AGREEMENT, NO WEIGHT SHALL BE PLACED UPON THE FACT THAT THIS AGREEMENT HAS BEEN DRAFTED BY CHASE, AND IT SHALL NOT ASSERT THAT THIS AGREEMENT IS UNENFORCEABLE OR INVALID ON THE GROUNDS THAT IT IS A CONTRACT OF ADHESION, THAT IT IS UNCONSCIONABLE, OR ANY SIMILAR THEORY. AFFILIATE UNDERSTANDS THAT CHASE MAY AT ANY TIME (DIRECTLY OR INDIRECTLY) SOLICIT CUSTOMER REFERRALS ON TERMS THAT MAY DIFFER FROM THOSE CONTAINED IN THIS AGREEMENT. 

# 23. Governing Law 

This Agreement will be governed in all respects by the laws of the State of Delaware, including its conflict with law provisions. 

Accept. 

# Appendix 

List of Restricted Trademark Terms 

Partner Restricted Trademark Terms 

Chase Brand Add Chase as a negative Keyword to your Search strategy. 

In addition, the following terms are prohibited: Chase, Chase bank, www.chase.com, www.creditcardsatchase.com, www.chasecreditcard.com, chase.com, creditcardsatchase.com, chasecreditcard.com, 

chase credit card, chase credit cards, Chase Freedom, Freedom Card 

AARP AARP.org, AARP.com, AARP membership, AARPmagazine.com, AARPhealthcare.com, AARP foundation, AARP passport, www.travelocity.com/AARP, AARP Bulletin, American Association of Retired Persons, AARP Insurance, AARP partner, AARP providers, AARP advocacy, Segunda Juventud, AARP Hot Deals 

Amazon Amazon, Amazon.com, www.amazon.com, Amazon Books, Amazon DVD, Amazon Movies, Amazon Music Borders Borders, Borders Stores, Borders Books, www.borders.com, www.bordersbooks.com Waldenbooks, Waldenbooks Stores, www.waldenbooks.com, www.waldenbooksstores.com 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

British Air British Airways, British Air, www.britishairways.com, www.ba.com, ba, Continental See Continental Tab Disney See “Disney” Tab Hess Hess, www.hess.com, Amerada Holiday Inn/Priority Club Holiday Inn, Holiday Inn Express, Priority Club, IHG, www.ichotelsgroup.com, InterContinental, InterContinental Hotels Group, Crowne Plaza, Hotel Indigo, Staybridge Suites, Candlewood Suites, 

Marathon Marathon, Marathon Oil, Marathon Petroleum Company, Speedway, Speedway SuperAmerica, SuperAmerica Marriott www.marriottrewards.com, www.marriott.com, Marriott, Marriott Rewards 

Overstock overstock.com, www.overstock.com, overstocked.com, overstock/com, overstock com, overstock com, overstockcom, overstock .com, overstock?com, overstock>com, overstock, overstocked.com, overstocks.com, over stock.com, overstock .com, overstockcom 

Sony Sony, www.sonystyle.com, ImageStation, My Sony, Vaio, EverQuest 

Speedway Speedway SuperAmerica, Speedway, SuperAmerica, Speedy Rewards, Marathon, Marathon Oil, Marathon Petroleum Company Starbucks Starbucks, Starbucks Coffee, Starbucks Foundation, Starbucks Coffee Company, Starbucks Corporation Subaru Subaru, My Subaru, Subaru World, Subaru of America 

Toys www.toysrus.com, Toysrus.com, Toys “R” Us, Toys “R” Us International, Kids”R”Us, Babies”R”Us, Babiesrus.com, Toyologist, Toysrus/Amazon, Babiesrus/Amazon, www.personalizedbyrus.com 

Trump Trump, www.trump.com, The Apprentice, Trumped, Trump University, Trump Taj Mahal, Trump Plaza, Trump Marina, Trump Indiana, Trump Club Privee, Trump National Golf Club, Trump Tower, Trump Park Avenue, Trump World Tower, Trump International Hotel & Tower, Trump Place, Trump Palace, Trump Parc & Trump Parc East, Trump Grande, Mar-a-Lago United See “United” Tab 

Universal Universal, Universal Studios, Universal Movies, Unviersal Entertainment, Universal Hollywood, www.universal.com, Universal movie tickets, universal movie ticket, universal theme parks, universal discount, universal discounts, universal ticket, universal tickets, universal vacation, universal vacations, universal travel, universal deals, universal offer, universal offers, universal park, universal parks, universal getaway, universal getaways, universal family getaway, universal family getaways, universal deal, universal deals 

Volkswagen Volkswagen, Volkswagen International, Volkswagen Group, Volkswagen AG, Audi 

Disney Restricted Key Words cheap disney vacation disney world vacations cheap disney vacations disneyland bargain child vacation disneyland bargains childrens vacations disneyland cheap discount disney travel disneyland discount discount disney vacation disneyland discounts discount disney vacations disneyland offer discount vacation disneyland offers discount vacations disneyland promotion 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

disney disneyland promotions disney bargain disneyland save disney bargains disneyland save disney cheap disneyland savings disney cruise disneyland savings disney cruise vacations disneyland travel disney deal disneyland trip disney discount disneyland trips disney family vacation disneyland vacation disney family vacations disneyland vacations disney florida vacation disneyworld bargain disney florida vacations disneyworld bargains disney golf vacations disneyworld cheap disney honeymoon disneyworld offer disney honeymoon vacation disneyworld offers disney honeymoons disneyworld promotions disney offer disneyworld save disney offers disneyworld savings disney package disneyworld vacation disney package vacations disneyworld vacations disney promotion family vacation disney promotions family vacations disney resort kid vacation disney resort vacation kids vacations disney resort vacations magic kingdom disney resorts orlando disney vacations disney savings orlando rentals disney travel orlando vacations disney travel package special disney travel disney vacation special vacation packages disney vacation club walt disney bargain disney vacations walt disney bargains disney vacations florida walt disney cheap disney vacations orlando walt disney deal disney world bargain walt disney deals disney world bargains walt disney offer disney world cheap walt disney offers disney world discount walt disney resort vacations disney world offer walt disney save disney world offers walt disney savings disney world package walt disney vacation disney world save walt disney vacations disney world savings walt disney world vacation disney world vacation walt disney world vacations 

United Restricted Key Words united airlines united air fare united united airlines reservations online united air united airline fare united.com United Escapes united airline international united flights www.united.com untied air united flight united first class unitedairlines.com United Vacation 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

UAL united travel united airlines.com united star alliance ual.com united airlines specials united air lines united discounts www.unitedairlines.com united trip united airlines schedule travel with united united airline travel united airlines discounts united reservation united airlines official website www.ual.com united business class united express united airlines airports united reservations united airlines star alliance www.united airlines.com united non-stop flights united fares united packages united airline flight international united travel united and airlines united airlines economy plus United Vacations united airports united airlines tickets united group travel united airlines flights United Escape united express airlines easy update united flights united air vacations unitedair united fare sale United airfare united last minute fares www.united airlines united efares untied airlines united getaways www.unitedairlines united low fares united airline.com united airlines bookings united air line cities united flies united airlines travel fly on united united airlines homepage united airlines group travel united airlines website united airlines travel certificates united destinations United Easy Update united airline flights united airlines business travel united airlines home page united special deals United airfares united business travel e-fares untiedair united airlines site united economy class united airlines fares united package deals www.unitedairline.com international united ticket united airlines home international united tickets united airlines vacations shop for united flights vacation travel United EasyUpdate united specials fly with united www.united airline.com united e fares unitied airlines united travel certificates united deals united air star alliance international united flight united fare search united airlines online United Escapes united e-fares international united flight united airlines cities united airlines online united air fare united e-fares united airlines reservations online united airlines cities united airline fare 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

Continental Restricted Key Words Continental airlines Continental air fare Continental Continental airlines reservations online continental.com Continental airline fare continental airline international Continental flights www.continental.com Continental air continental flight Continental first class continental air lines Continental Vacation continental airlines schedule Continental travel continental airline travel Continental airlines specials continental reservation Continental discounts continental reservations Continental trip continental fares travel with Continental continental airline flight Continental airlines discounts continental and airlines Continental airlines official website Continental Vacations Continental business class continental airlines tickets Continental airlines airports continental airlines flights Continental non stop flights continental flights continental airlines Continental packages continental air line International Continental travel continental airlines travel Continental airports continental airlines homepage Continental group travel continental airlines website Continental air vacations continental destinations Continental fare sale continental airlines vacations Continental last minute fares continental air fare Continental getaways continental airlines reservations online Continental low fares continental airline fare Continental airlines bookings international continental flight cities Continental flies continental airlines online fly on Continental continental airlines cities Continental airlines group travel Continental economy class Continental airlines travel certificates Continental package deals Continental airlines business travel international Continental ticket Continental special deals international Continental tickets Continental business travel shop for Continental flights fly with Continental 

Source: CREDITCARDS.COM, INC., S-1, 8/10/2007 

