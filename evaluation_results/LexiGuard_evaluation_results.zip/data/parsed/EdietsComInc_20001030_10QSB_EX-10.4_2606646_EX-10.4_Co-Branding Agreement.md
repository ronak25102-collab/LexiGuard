EXHIBIT 10.4 

CO-BRANDING AGREEMENT 

THIS CO-BRANDING AGREEMENT (the "Agreement") is made as of May 22, 2000 (the "Effective Date"), by and between WOMEN.COM NETWORKS, INC., a Delaware corporation having a place of business at 1820 Gateway Drive Suite 150, San Mateo, CA 94404 ("Women.com"), and EDIETS.COM, INC., a Delaware corporation, having its principal place of business at 3467 West Hillsboro Boulevard, Suite 2, Deerfield Beach, Florida 33442 ("eDiets"). 

WHEREAS, eDiets maintains a site on the Internet, currently located at http://www.eDiets.com (the "eDiets Site"), that provides personalized diet and counseling on-line; 

WHEREAS, Women.com maintains sites on the Internet, currently located at http://www.women.com (the "Women.com Sites"), that provides an on-line portal for women, blending content, community, commerce and services; 

WHEREAS, eDiets and Women.com wish to establish and maintain a custom, category-exclusive, co-branded center containing repackaged content from the eDiets Site, including a free personal diet profile, which will be a part of the Women.com Sites, in order to promote the eDiets brand and drive traffic to the eDiets Site. 

NOW THEREFORE, in consideration of the mutual covenants, representations and warranties set forth herein, the parties hereby agree as follows: 

1.       THE DIET CENTER. 

1.1 Women.com will name an area, in which eDiets content will be published (such area, the "Diet Center"). Links (presented as Diet Center logos) to the Diet Center will be located on three Women.com channels (the Fitness Channel www.women.com/fitness; the Health Channel www.women.com/health; and the Food Channel www.women.com/food) and two subchannels within such channels to be determined in accordance with Exhibit B hereto. The first page of the Diet Center (the "Gateway Page") will have the look and feel of the Women.com Sites as specified in Exhibit A hereto. The Diet Center shall be branded with an icon that includes the eDiets logo. There will be no Women.com or eDiets registration required to enter and use the Gateway Page of the Diet Center. Women.com and eDiets will mutually agree upon the content and logo of the Gateway Page, including the display, appearance and placement of the Diet Center's logo, in accordance with the terms of this Agreement, including the specifications set forth on Exhibit A hereto, prior to the launch date of the Diet Center (the "Launch Date"). eDiets and Women.com shall work together in good faith in order to implement such design and development and the continued enhancement of the Diet Center. 

1.2 Women.com shall store and maintain the Gateway Page on, and serve the Gateway Page from, server(s) located on Women.com's premises or the premises of Women.com's third party web host. eDiets shall store and maintain the Diet Center beneath the Gateway Page, and serve the Diet Center beneath the Gateway Page from, server(s) located on eDiets' premises or the premises of eDiets' third party web host. Effective one week from the 

1 

Launch Date, eDiets shall include a back button to the Women.com Site on all pages of the Diet Center beneath the Gateway Page. If at any time during the Term of this Agreement, eDiets reasonably believes that the inclusion of such back buttons has a material negative effect upon the rate at which users of the Diet Center register to become members of eDiets or convert into registered participants of the services offered by eDiets on the Diet Center (the "Negative Effect"), eDiets may conduct a one (1) month test of the effect of such back buttons which may include the exclusion of the back button. If such test verifies the Negative Effect of the back button(s) to the Women.com Site, eDiets may remove any such back buttons. 

1.3 Except as set forth in **Section 1.2** **_[Women]_** , eDiets will have sole responsibility for providing and maintaining at its own expense the Diet Center beneath the Gateway Page. eDiets and Women.com will work together regarding the on-going design and maintenance of the Diet Center. 

1.4 Each party shall bear its own expenses related to its responsibilities under this Section 1. 

# 2.       EDIETS OBLIGATIONS. 

2.1 Content License. eDiets hereby grants to Women.com, subject to the terms and conditions of this Agreement, a non-exclusive, nontransferable, worldwide, royalty-free license to use, copy, reproduce and display the editorial content and other data, branding and other identification provided by eDiets to Women.com in connection with this Agreement (the "eDiets Content") on the Women.com Sites: (i) for publication in the Diet Center and elsewhere throughout the Women.com Sites; (ii) for the promotion of eDiets and the Diet Center on the Women.com Sites and in collateral advertising materials; and (iii) for such other purposes as are consistent with or otherwise authorized under this Agreement. 

2.2 Delivery of Content. eDiets agrees to deliver to Women.com, by no later than fifteen (15) days after the Effective Date, in a format specified by Women.com, the initial eDiets Content required by this Agreement, including any photos, text, data, illustrations, graphical elements, animation or banner ads. All eDiets Content delivered under this Agreement shall be consistent with the specifications for such eDiets Content (including specifications as to manner and media), and otherwise in accordance with, the terms of this Agreement, 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

including Exhibit D hereto, and any production schedules developed by the parties from time to time. eDiets agrees that it will respond in a timely manner to be agreed upon by the parties to all reasonable requests made by Women.com or its agents for updated eDiets Content and refreshing of eDiets Content for the Women.com Sites. 

2.3 Format. eDiets will deliver the eDiets Content in such 

"camera-ready" or digital format, as agreed to by the parties. 

2.4 Editorial Guidelines. eDiets shall ensure that the eDiets Content complies with Women.com's editorial guidelines. Women.com will provide eDiets with specific editorial guidelines for eDiets Content. Women.com reserves the right to reject any and all content that does not meet Women.com's editorial guidelines. eDiets will then be required to edit such 

2 

content until all content provided by eDiets complies with Women.com's editorial guidelines and standards. In the event that eDiets fails, within five (5) days after submission by Women.com, to provide Women.com with necessary revisions thereto, such failure shall be deemed to be approval of Women.com's edits. Women.com reserves the right, in its sole discretion, to require eDiets to eliminate, any banner, hypertext or other link from the Women.com Site to any web site containing content promoting or advertising tobacco, liquor, controlled substances, gambling, firearms or sexually explicit, offensive or degrading material. In addition to the foregoing and the content guidelines set forth in **Section 5.2** **_[EXCLUSIVITY]_** hereof, eDiets may not directly link from the Gateway Page to any Women.com Competitive Company (as defined in **Section 5.2** **_[EXCLUSIVITY]_** ). 

2.5 Facts. eDiets shall be solely responsible for ensuring the timeliness, accuracy, and correctness of all facts, data and information ("Facts") contained within the eDiet Content. eDiets shall indemnify, defend and hold harmless Women.com, its officers, directors, employees and agents from and against all damages, awards, costs, fees (including reasonable attorneys' fees), and expenses that such parties may incur as a result of third party claims arising from such third parties' reliance on Facts. Women.com retains the right, but not the obligation, to independently corroborate, or have corroborated, the timeliness, accuracy, and correctness of all Facts. 

# 3.       ADVERTISING. 

3.1 Advertising and Promotion. Advertising and Promotion. Women.com shall make available to eDiets and eDiets shall purchase from Women.com advertising and promotional inventory in the amounts and at the rates specified in Exhibit B hereto and in accordance with the terms specified in Exhibit D hereto. If Women.com does not deliver at least 80% of the Quarterly Impression Guarantee for Advertsing Promotions as set forth on Exhibit B (11,250,000 per quarter; 45,000,000 per year); 80% of the Quarterly Impression Guarantee for the Diet Center Logo as set forth on Exhibit B (3,250,000 per quarter; 13,000,000 per year); and 80% of the Quarterly Impression Guarantee for Other Campaigns as set forth on Exhibit B (3,000,000 per quarter; 12,000,000 per year) each quarter following the Launch Date, within sixty (60) days of the end of the applicable quarter, Women.com shall deliver an amount equal to the under-delivery within the same campaign elements, including newsletters, promotions, exclusive sponsorships, targeted rotations, ROS, channel and sub-channel center logo placements, or mutually agreed upon comparable elements. If Women.com does not deliver the shortfall within sixty (60) days of the end of the applicable quarter, eDiets may terminate this Agreement in its entirety immediately or authorize Women.com to deliver the shortfall within an extended number of days to be mutually agreed upon by the parties (the "Make Good Period"). Should eDiets elect to terminate this Agreement, Women.com shall reimburse eDiets within thirty (30) days of the date of such termination for all pre-paid impressions or other promotions not delivered as of the date of termination. Women.com agrees that if eDiets elects to extend the Agreement the monthly fee due and payable during the Make Good Period will be recalculated and reduced to reflect the changes in the revised delivery schedule. 

3 

3.2 Women.com and eDiets agree that all media metrics (e.g. pageviews and impressions) with respect to the Gateway Page of the Diet Center shall be allocated to Women.com. 

4. PUBLICITY. Neither party will make any public statement, press release or other announcement relating to the terms of or existence of this Agreement without the prior written consent of the other. Notwithstanding the foregoing, each party hereby grants to the other the right to issue an initial press release, the timing and wording of which will be subject to such party's reasonable approval, regarding the relationship between Women.com and eDiets and the launch of the Diet Center. This Section shall not in any way restrict either party from complying with any law, regulation or other governmental demand or request for information. 

5.       EXCLUSIVITY. 

5.1 During the Term, (a) Women.com will not buy, sell, display, distribute advertising from (including, but not limited to, banner ads, buttons, badges, text links, hyperlinks or editorial mentions) or otherwise promote a Competitive Company on any page of the Diet Center; (b) eDiets will be the exclusive third party provider of content and interactive tools for diets and diet counseling to Women.com within the Diet Center; (c) Women.com will not enter into a relationship with a Competitive Company that involves any of the following; (i) custom developed mini or micro web sites; (ii) content integration; (iii) discounts offered only to Women.com members on the Member Central page of the Women.com Sites; (iv) editorial endorsement (such as 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

"Brought to you by....") or fixed placement of 468x60 (top) and 125x365 (side) banners within eight (8) of the Content Features selected by eDiets; and (v) anchor sponsorship in any multi-sponsor Women.com promotion. Notwithstanding the foregoing, Women.com shall be entitled to (aa) provide mini and micro web sites and Women.com promotions and sponsorships to Jenny Craig; (bb) sell, display, or distribute advertisements, including banner advertisements, newsletter placements, internet radio, commerce placements and market research, or otherwise promote Competitive Companies on pages other than the Gateway Page of the Diet Center. For purposes of this Agreement, "Competitive Company" means any company that eDiets reasonably presents as, and Women.com reasonably agrees is, a direct competitor to eDiets by distributing on-line content principally relating to diets and diet counseling, including, but not limited to, Weight Watchers, Jenny Craig, NutriSystem, Nutrio, Asimba, DietSmart and uMagic. 

During the Term, Women.com agrees to give eDiets the right of first refusal to participate in all diet and diet-counseling related promotion opportunities created or otherwise made available by Women.com on channels or sub-channels created after the Effective Date of this Agreement, including sponsorships, anchor placements and any other content integration opportunities ("Diet Promos"). If Women.com proposes to create and make available Diet Promos after the Effective Date, it shall give eDiets written notice of its intention, describing the terms and conditions of participation in the Diet Promos. eDiets shall have fifteen (15) days from the giving of such notice to agree to participate in the applicable Diet Promo upon the terms and conditions specified in the notice by giving written notice of its agreement to Women.com. 

4 

5.2 During the Term, eDiets will not buy, sell, display or distribute advertising from (including, but not limited to, banner ads, buttons, badges, text links, hyperlinks or editorial mentions) or otherwise promote any Women.com Compettive Company on any page of the eDiets Site that is within two clicks from the Gateway Page of the Diet Center. For purposes of this Agreement, "Women.com Competitive Company" means any company that Women.com reasonably presents as, and eDiets reasonably agrees is, a direct competitor to Women.com by providing an on-line portal for women, including, but not limited to, Oxygen Media and iVillage, 

# 6.       PAYMENTS. 

6.1 Payment Schedule. In consideration of Women.com's developing, maintaining and promoting the Diet Center pursuant to this Agreement, beginning on the tenth (10th) day after the execution of this Agreement and thereafter on the last day of each month during the Term of this Agreement, eDiets shall pay to Women.com a monthly fee in the amount set forth on Exhibit C unless adjusted as set forth in **Section 3.1** **_[Advertising and Promotion]_** . Following the Initial Term, Women.com shall have the right, upon no fewer than sixty (60) days prior written notice to eDiets, to increase the amount of the Payment Schedule; provided, that (i) Women.com may not increase the Payment Schedule more than once in any period of twelve (12) consecutive months; and (ii) such increase may not exceed twenty percent (20%) of the then current Payment Schedule. 

7.       REPORTING. 

7.1 Women.com shall make advertising reports generated by NetGravity available to eDiets either online or in some other mutually agreed upon format. Such reports shall contain the number of impressions and other metrics attributable to each general category of advertising specified in Exhibit B hereto, as well as such other information as eDiets may reasonably request, to the extent reasonable commercial efforts and current technology permit. eDiets agrees to accept such advertising reports provided by Women.com as the official basis for measuring all services to be provided under this Agreement, provided, however, that if the traffic data contained in such reports materially differs (meaning a differential of 25% or more), from the data captured and reported by eDiets, the parties agree to either (a) identify the source of and remedy the difference or (b) equally split the difference between the traffic data reported by each party. If a technological malfunction causes the data reported by NetGravity to materially inflate the number of impressions provided eDiets by Women.com, Women.com shall deliver eDiets an amount of impressions equal to the overcount in accordance with the provisions for under-delivery set forth in **Section 3.1** **_[Advertising and Promotion]_** hereof. 

8.       OWNERSHIP. 

8.1 eDiets Content. Nothing in this Agreement shall effect a transfer of ownership in the eDiets Content from eDiets to Women.com, and eDiets shall retain all rights of copyright, trademark or other intellectual property rights in such eDiets Content that it possessed prior to providing such eDiets Content to Women.com, subject only to the licenses expressly granted by eDiets to Women.com by this Agreement. eDiets retains all rights with respect to eDiets 

5 

Content that are not specifically granted to Women.com herein. Women.com acknowledges that eDiets owns all right, title and interest in and to the eDiets Content, and Women.com shall not now or in the future contest the validity of the eDiets' ownership rights in and to the eDiets Content. eDiets agrees to periodically include mention of Women.com, including a link to the Women.com Site if desired by eDiets, within the eDiets Newsletter (the "Mention"). eDiets shall determine in its sole discretion the placement, frequency and timing of such Mention, provided that eDiets submits each Mention to Women.com for approval and secures such approval prior to publication or distribution of such Mention. 

8.2 Women.com Content. All content, including but not limited to all 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

photos, text, data, illustrations, graphical elements, animation and tools, appearing on the Women.com Sites (with the exception of the eDiets Content) or provided to eDiets pursuant to this Agreement by Women.com, including all software, methods of operation, interfaces, specifications and documentation in respect of the foregoing contained therein (collectively, "Women.com Content") is and shall remain the sole and exclusive property of Women.com or its third party licensors and eDiets acquires no right, title or interest therein or thereto. 

8.3 Data Ownership. Women.com routinely collects data from Women.com visitors to the Women.com Sites. Women.com shall retain all ownership, right, title and interest in and to any data provided to Women.com by Women.com users while directly on the Women.com Site. eDiets shall retain all ownership, right, title and interest in and to any data collected within the eDiets Site including, but not limited to demographic information and email addresses submitted to eDiets by users of the eDiets Site. 

8.4 Privacy. eDiets agrees to treat all consumer data collected from Women.com users on the Women.com Site in accordance with Women.com's privacy and security policies (the "Women.com Data"). Women.com reserves the right to change such policies in its sole discretion from time to time. In no event shall eDiets disclose or otherwise transfer to any person or entity any Women.com Data that individually or in the aggregate identifies the identity, habits or transactions of the Women.com users. 

8.5 Tools. To the extent either party, directly or indirectly, utilizes any software, HTML and/or Java scripts, proprietary tools and/or methodologies (collectively the "Tools") in performing under this Agreement, such party and its licensors retain all right, title and interest in and to any such Tools. 

9.       TRADEMARK OWNERSHIP AND LICENSE. 

9.1 Women.com Marks. Women.com hereby grants eDiets a non-exclusive, non-transferable, royalty-free worldwide right and license without the right to sublicense to use the Women.com Marks during the Term solely in connection with (i) the fulfillment of eDiets' obligations under this Agreement, and (ii) in advertising and marketing collateral related to this Agreement. eDiets acknowledges and agrees that Women.com owns and otherwise has the exclusive right to use and to license the Women.com Marks and that Women.com, in each instance, shall have the right to review and approve or disapprove eDiets' use of the Women.com Marks, such approval not to be unnecessarily withheld or delayed. All uses of 

6 

Women.com Marks by eDiets, including all goodwill arising therefrom shall inure solely to the benefit of Women.com. Women.com retains all rights with respect to Women.com Marks that are not specifically granted to eDiets herein. Women.com, in its sole discretion, may withdraw specific or general permission to use the Women.com Marks upon seventy-two (72) hours written notice to eDiets. Upon expiration of such notice period, eDiets shall immediately discontinue use of the applicable Women.com Marks. As used herein, "Women.com Marks" means all trademarks, service marks and corporate and brand identification and indicia, including without limitation word marks, logos and other picture marks, phrases, jingles, composite marks, corporate, commercial and institutional images, product designations and identifications of Women.com, whether registered or not. 

9.2 eDiets Marks. eDiets hereby grants Women.com a non-exclusive, non-transferable, royalty-free worldwide right and license without the right to sublicense to use the eDiets Marks during the Term solely in connection with (i) the fulfillment of Women.com's obligations under this Agreement, and (ii) in advertising and marketing collateral related to this Agreement. Women.com acknowledges and agrees that eDiets owns and otherwise has the exclusive right to use and to license the eDiets Marks and that eDiets shall have the right, in each instance, to review and approve or disapprove Women.com's use of the eDiets Marks, such approval not to be unnecessarily withheld or delayed. All uses of eDiets Marks by Women.com, including all goodwill arising therefrom shall inure solely to the benefit of eDiets. eDiets retains all rights with respect to eDiets Marks that are not specifically granted to Women.com herein. eDiets, in its sole discretion, may withdraw specific or general permission to use the eDiets Marks upon seventy-two (72) hours written notice to Women.com. Upon expiration of such notice period, Women.com shall immediately discontinue use of the applicable eDiets Marks. As used herein, "eDiets Marks" means all trademarks, service marks and corporate and brand identification and indicia, including without limitation word marks, logos and other picture marks, phrases, jingles, composite marks, corporate, commercial and institutional images, product designations and identifications of eDiets, whether registered or not. 

9.3 Usage. All uses by one party of the other party's Marks shall be in accordance with such quality control standards as the licensing party may promulgate from time to time and each party agrees to refrain from all uses of the other party's Marks to which the other party objects. All promotional literature and other materials prepared by a party in connection with its promotional obligations hereunder shall bear appropriate copyright and/or trademark notices as prescribed by the other party, if the other party's content or branding is included therein. Each party agrees that it will not use, register or attempt to register in any jurisdiction, or otherwise appropriate or adopt any name, mark or logo that is confusingly similar to the other party's Marks. At no time during the term of the Agreement or thereafter shall eDiets attack, challenge or file any application with respect to any Women.com Mark. At no time during the term of the Agreement or thereafter shall Women.com attack, challenge or file any application with respect to any eDiets Mark. 

9.4 Non-Alteration. In any identification of either party pursuant to this Agreement, one party shall not alter or otherwise impair the branding or other identification of the other party, nor alter or remove any copyright, 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

trademark or other protective notices of such other 

7 

party. Women.com agrees that, except as may be reasonably necessary, it shall not mask, frame, overlay, impair or otherwise materially alter or affect the images, information, perception, service quality or security obtained from a eDiets Site once the link or equivalent pathway is selected or initiated. 

10.      TERM AND TERMINATION. 

10.1 Initial Term. This Agreement will become effective as of the Effective Date and, unless sooner terminated pursuant to **Sections 3.1** **_[Advertising and Promotion]_** or **10.2** **_[Termination for Breach]_** , shall remain effective for two (2) years from and after the Effective Date (the "Initial Term"). This agreement shall automatically renew for additional successive terms of twelve (12) months each at the end of the Initial Term ("Renewal Terms"), unless either party notifies the other in writing at least sixty (60) days prior to the end of the Initial Term. As used in this agreement, "Term" shall mean the Initial Term and the Renewal Terms, if any. 

10.2 Termination for Breach. In the event of a material breach of this Agreement by either party, the non-breaching party may terminate this Agreement if such breach is not cured within thirty (30) days from receipt of written notice of such breach sent to the address of the breaching party as specified herein. Such termination shall be in addition to any and all other actions or remedies the parties may seek at law or equity with respect to a breach of this Agreement. 

10.3 Effect of Termination. Upon the termination, expiration or earlier termination of this Agreement in accordance with its terms (the "Termination Date"): 

(a) the rights and licenses granted by each party to the other pursuant to this Agreement shall automatically terminate; 

(b) where applicable, each party shall return to the other party, within thirty (30) days from such Termination Date, all intellectual property, technology or other property in its possession used in connection with this Agreement that is proprietary to the other party; 

(c) Confidential Information shall be returned in accordance with the terms of Section 11; 

(d) within sixty (60) days after such Termination Date, Women.com shall remove and cease to use all eDiets Content provided or made available for use or display on the Gateway Page pursuant to or in connection with this Agreement; 

(e) within sixty (60) days after such Termination Date, each party shall eliminate from their respective web sites and/or respective web pages any marks or branding related to the other party (i.e., the eDiets Marks and the Women.com Marks, respectively) used in connection with this Agreement; 

8 

(f) within sixty (60) days after such Termination Date, Women.com shall purge from its servers and systems all eDiets Content; 

(g) within sixty (60) days after such Termination Date, Women.com shall make-good to eDiets any and all payments made to Women.com under this Agreement for advertising inventory not yet delivered or run, provided that eDiets has paid for such inventory; and 

(h) within sixty (60) days after such Termination Date, eDiets shall pay to Woman.com any and all payment due under this Agreement for delivered advertising and promotions inventory in accordance with **Sections 3.1** **_[Advertising and Promotion]_** and 6.1. 

10.4 Survival. The provisions of Sections 4, 8, 10, 11, 12, 13, 14 and 15, as well as all defined terms, will survive any expiration or earlier termination of this Agreement for any reason. 

11.      CONFIDENTIALITY. 

11.1 The parties acknowledge that, in the course of performing duties under this Agreement, each party may obtain Confidential Information from the other party. For the purposes of this Section 11, the party disclosing Confidential Information shall be the "Disclosing Party" and the party receiving Confidential Information shall be the "Receiving Party." "Confidential Information" means any and all technical and non-technical information provided by the Disclosing Party to the Receiving Party and shall include, but not be limited to, all information regarding (a) patent and patent applications, (b) trade secrets, and (c) proprietary information, ideas, samples, media, techniques, sketches, drawings, works of authorship, models, inventions, know-how, processes, apparatuses, equipment, algorithms, software programs, software source documents, and formulae related to the current, future, and proposed products and services of the Company, and including, without limitation, the Company's information concerning research, experimental work, development, design details and specifications, engineering, financial information, procurement requirements, purchasing, manufacturing, customer lists, investors, employees, business and contractual relationships, business forecasts, sales and merchandising, marketing plans and information the Company provides regarding third parties. Confidential Information also includes proprietary or confidential information of any third party that may disclose such information to either party in the course of such party's business. 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

Confidential Information may be disclosed in writing, in other tangible form, orally or visually. 

11.2 Confidential Information of the Disclosing Party will not include information that the Disclosing Party can demonstrate by reasonable evidence (a) is in or enters the public domain without breach of this Agreement, (b) the Receiving Party lawfully receives from a third party without restriction on disclosure and without breach of a nondisclosure obligation, (c) is approved for release by written authorization of the Disclosing Party, (d) the Receiving Party knew prior to receiving such information from the Disclosing Party or (e) is independently developed by the Receiving Party without reference to Confidential Information of the Disclosing Party. 

9 

11.3 By virtue of this Agreement, each party hereto may disclose to the other any information that is Confidential Information. Such Confidential Information shall be governed by the terms of this Section 11. Each party agrees to use the Confidential Information of the other party solely to the extent necessary to fulfill its obligations or exercise its rights hereunder, and not for any other purpose. 

11.4 Each party agrees (a) that it will disclose such Confidential Information only to its employees, agents and contractors with a need to know such Confidential Information and who have obligations of confidentiality not to use such Confidential Information for any purpose except as expressly permitted hereunder, (b) that it will not disclose to any third party or use any Confidential Information disclosed to it by the other except as expressly permitted in this Agreement, and (c) that it will take all reasonable measures to maintain the confidentiality of all Confidential Information of the other party in its possession or control, which will in no event be less than the measures it uses to maintain the confidentiality of its own information of similar importance. 

11.5 Notwithstanding the foregoing, each party may disclose Confidential Information (a) to the extent required by a court of competent jurisdiction or other governmental authority or otherwise as required by law, provided that the Receiving Party uses reasonable efforts to provide the Disclosing Party with prior notice of such obligation in order to permit the Disclosing Party a reasonable opportunity to take legal action to prevent or limit the scope of such disclosure, or (b) on a "need-to-know" basis under an obligation of confidentiality to its legal counsel, accountants, banks and other financing sources and their advisors. 

11.6 Within fifteen (15) days of receipt by Receiving Party of a written request from the Disclosing Party for the return of Confidential Information, all Disclosing Party's Confidential Information and all copies thereof in Receiving Party's possession or control shall be returned to Disclosing Party or destroyed by Receiving Party at Disclosing Party's instruction. Receiving Party shall then certify the same in writing and that no copies have been retained by Receiving Party, its employees, agents or contractors. 

11.7 Each party acknowledges that unauthorized disclosure or use of the Confidential Information may cause irreparable harm to the other party for which recovery of money damages would be inadequate, and the other party shall therefore be entitled to seek timely injunctive relief to protect its rights under this Section 11, in addition to any and all other remedies available at law or in equity. 

11.8 The terms and conditions of this Agreement will be deemed to be the Confidential Information of each party and will not be disclosed without the written consent of the other party. 

12.      WARRANTY. 

12.1 General. Each party represents and warrants to the other that: (a) such party has the full corporate right, power, and authority to enter into this Agreement and perform the acts required of it hereunder, (b) the execution of this Agreement by such party, and the performance 

10 

by such party of its obligations and duties hereunder, do not and will not violate any agreement to which such party is a party or by which it is bound, (c) when executed and delivered by such party, this Agreement will constitute the legal, valid and binding obligation of such party, enforceable against such party in accordance with its terms and (d) such party will perform its obligations hereunder in compliance with applicable law and regulations. 

12.2 eDiets Warranties. eDiets hereby represents and warrants to and for the benefit of Women.com and its Affiliates that: 

(a) the eDiets Content may be used by Women.com as permitted by this Agreement without violating or infringing the rights of any person or entity, including, without limitation, rights of privacy or publicity, contractual rights, copyright, trademark, or other Intellectual Property rights; 

(b) publication of the eDiets Content by Women.com as permitted by this Agreement will not constitute defamation, product disparagement or trade libel; 

(c) the use of the eDiets Marks by Women.com as permitted by this Agreement will not infringe or violate the trademark, service mark or trade dress rights of any Person; and 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

(d) during the Term of this Agreement, the pages of the eDiets Site to which the Gateway Page provides links shall operate in accordance with the specifications set forth on Exhibit D. 

For the purposes of this Agreement, "Affiliate" shall mean another entity that controls, is controlled by or is under common control with such party; provided, however, that such entity is not a human being. For purposes of this definition, the terms "controls," "is controlled by," or "is under common control with," refer to the power to direct the policies and day-to-day operations of an entity, whether by virtue of ownership of a voting securities, contract, or otherwise. 

12.3 Women.com Warranties. Women.com hereby represents and warrants to and for the benefit of eDiets and its Affiliates that: 

(e) that the Women.com Content, except to the extent of any eDiets Content incorporated therein, used in connection with this Agreement does not and will not violate or infringe the rights of any person or entity, including, without limitation, rights of privacy or publicity, contractual rights, copyright, trademark, or other intellectual property rights; 

(f) that publication of the Women.com Content will not constitute defamation, product disparagement or trade libel; 

11 

(g) that the use of the Women.com Marks by eDiets as permitted by this Agreement will not infringe or violate the trademark, service mark or trade dress rights of any person or entity. 

12.4 Sole Remedy. Each party agrees that the sole and exclusive remedy for a breach of the warranties set forth in this Section 12 shall be the indemnification set forth in Section 13 below. 

12.5 EXCEPT AS SPECIFIED IN THIS AGREEMENT, NEITHER PARTY MAKES ANY WARRANTY IN CONNECTION WITH THE SUBJECT MATTER OF THIS AGREEMENT AND HEREBY DISCLAIMS ANY AND ALL IMPLIED OR STATUTORY WARRANTIES, INCLUDING ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY, NONINFRINGEMENT AND FITNESS FOR A PARTICULAR USE OR PURPOSE REGARDING SUCH SUBJECT MATTER. NEITHER PARTY WARRANTS THAT ITS WEB SITE(S) OR THE CENTER WILL FUNCTION WITHOUT INTERRUPTION OR THAT THEY ARE ERROR FREE. To the extent that a party may not, as a matter of applicable law, disclaim any implied warranty, the scope and duration of such warranty shall be the minimum permitted under such law. 

# 13.      INDEMNIFICATION. 

13.1 Breach of Warranty. Subject to **Section 13.3** **_[Indemnification Requirements and Procedures]_** , eDiets and Women.com each agree to indemnify, defend and forever hold the other party, its present and former Affiliates, officers, members, stockholders, directors, employees, and agents, and successors and assigns (collectively, the "Indemnitees") harmless from and against any and all losses, liabilities, claims, costs, damages, fees and expenses (including, without limitation, fines, forfeitures, reasonable attorneys' fees, disbursements and administrative or court costs) (collectively, "Indemnifiable Sums") that the other party may incur as a result of third party claims arising from circumstances that constitute a breach or alleged breach of such party's warranties set forth in Section 12 or otherwise explicitly set forth in this Agreement. 

13.2 Products, Services and Content. 

(a) Women.com Liability. Subject to **Section 13.3** **_[Indemnification Requirements and Procedures]_** , Women.com agrees to indemnify, defend and forever hold harmless the eDiets Indemnitees from and against all Indemnifiable Sums arising out of third party claims to the extent such claims are based upon: (a) content published on the Women.com Sites, other than eDiets Content; (b) the operation of the Women.com membership program; or (c) any product or service, other than a product or service provided by eDiets, sold, licensed or otherwise made available on the Women.com Sites. (b) eDiets Liability. Subject to **Section 13.3** **_[Indemnification Requirements and Procedures]_** , eDiets agrees to indemnify, defend and forever hold harmless the Women.com Indemnitees from and against all Indemnifiable Sums arising out of third party claims to the extent such claims are based upon: (a) content published on the eDiets Sites, other than Women.com Content; (b) tools used on or in connection with the eDiets Site, including, but not limited to the Diet Tool; (c) the operation of the eDiets membership program; (d) any product or service sold, licensed or otherwise made 

12 

available on any eDiets Site; or (e) any product or service sold, licensed or made available by eDiets on the Diet Center. 

13.3 Indemnification Requirements and Procedures. Each party's obligation to indemnify the other pursuant to this Section 13, is predicated upon the indemnified party's (i) giving prompt written notice of any indemnifiable claim to the indemnifying party (provided that failure to give such notice shall not release the indemnifying party from its obligations hereunder except to the extent it is prejudiced thereby), (ii) giving the indemnifying party the opportunity to assume (by written notice to the Indemnitee) control over the defense and settlement of such claim, and (iii) providing, at the indemnifying party's expense, all relevant information, assistance and authority to enable to the indemnifying party to defend such claim. Each party, as Indemnitee, may participate, at its own cost, in the defense of any indemnifiable claim with counsel of its own choosing. Each party agrees not to settle any indemnifiable claim without the prior written consent of the other party, which consent shall not be unreasonably withheld or delayed. 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

13.4 Limitations on Indemnification. Notwithstanding the terms of 

**Sections 13.1** **_[Breach of Warranty]_** and **13.2** **_[Products, Services and Content]_** , an indemnifying party shall have no liability for, nor shall it indemnify, defend or hold any Indemnitee harmless from or against any claim based on: (a) use of old, superseded content or Marks if such infringement would have been avoided by the use of the current version of such content or replacement Marks made available by the indemnifying party to the other party; (b) use of content or Marks not in accordance with the terms of this Agreement; (c) any modification of the indemnifying party's content or Marks not made or explicitly authorized by the indemnifying party if, in the absence of such modification, the content or Marks would not be infringing; or (d) a claimed act of infringement or misappropriation which act occurred after the other party received notice of such potential claim. 

14.      LIMITATION OF LIABILITY. EXCEPT FOR BREACHES OF SECTION 11 OR BREACHES OF ANY LICENSE GRANT SET FORTH IN THIS AGREEMENT, IN NO EVENT WILL EITHER PARTY BE LIABLE TO THE OTHER FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES, WHETHER BASED ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE) OR OTHERWISE, WHETHER OR NOT THAT PARTY HAS BEEN ADVISED OF, KNEW, OR SHOULD HAVE KNOWN OF, THE POSSIBILITY OF SUCH DAMAGE AND NOTWITHSTANDING THE FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY. THE LIMITATIONS ON LIABILITY FOR DAMAGES SET FORTH IN THIS AGREEMENT SHALL BE INAPPLICABLE TO EACH PARTY'S CONTRACTUAL OBLIGATION TO INDEMNIFY THE OTHER PARTY AS SET FORTH IN SECTIONS 2.6 AND 13. 

15.      GENERAL. 

15.1 Assignment. Neither party may assign this Agreement, in whole or in part, without the other party's written consent (which will not be unreasonably delayed or withheld), except that no such consent will be required in connection with an assignment or transfer of this Agreement to (a) a party's successor in connection with a Change in Control of such party, provided that such successor is not a competitor of the other party, or (b) to any entity that is 

13 

controlled by, under common control with, or controls a party. For purposes hereof, the terms "control", "controlled by" or "under common control with" refer to the possession, directly or indirectly, of the power to direct or cause the direction of the management and policies of an entity, whether through the ownership of voting securities, by contract or otherwise. Any attempt to assign this Agreement other than as permitted above will be null and void. This Agreement shall be binding upon and inure to the benefit of the parties and their respective successors and assigns. For purposes of this Agreement, "Change in Control" means a merger or consolidation of the party with, or any sale of all or substantially all of the assets of such party to, any other person, corporation or entity, unless as a result of such merger, consolidation or sale of assets the holders of such party's voting securities prior thereto hold at least fifty percent (50%) of the total voting power represented by the voting securities of the surviving or successor corporation after such transaction. 

15.2 Jurisdiction and Venue. The parties agree that all lawsuits arising out of or related to this Agreement shall be brought in the state or federal courts located in the state of California, San Francisco County, and each party hereby referred consents to the exclusive personal jurisdiction of such courts for such purpose. 

15.3 Governing Law. This Agreement shall be interpreted and enforced in accordance with the laws of the State of California as applied to agreements made, entered into and performed entirely in California by California residents, notwithstanding the actual residence of the parties, without giving effect to any choice of laws of California that would require the application of the laws of a state other than California. 

15.4 Notice. Any notice under this Agreement will be in writing and delivered by personal delivery, express courier, confirmed facsimile, confirmed e-mail or certified or registered mail, return receipt requested, and will be deemed given upon personal delivery, one (1) day after deposit with express courier, upon confirmation of receipt of facsimile or e-mail or five (5) days after deposit in the mail. Notices will be sent to a party at its address set forth below or such other address as that party may specify in writing pursuant to this Section. 

15.5 No Agency. The parties are independent contractors and will have no power or authority to assume or create any obligation or responsibility on behalf of each other. This Agreement will not be construed to create or imply any partnership, agency or joint venture. 

15.6 Force Majeure. Any delay in or failure of performance by either party under this Agreement will not be considered a breach of this Agreement and will be excused to the extent caused by any occurrence beyond the reasonable control of such party including, but not limited to, acts of God, power outages and governmental restrictions. 

15.7 Severability. In the event that any of the provisions of this Agreement are held to be unenforceable, the remaining portions of the Agreement will remain in full force and effect. 

15.8 Entire Agreement. This Agreement is the complete and exclusive agreement between the parties with respect to the subject matter hereof, superseding that certain Letter of 

14 

Intent dated April 3, 2000, and any other agreements and communications (both 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

written and oral) regarding such subject matter. This Agreement may only be modified, or any rights under it waived, by a written document executed by both parties. 

WOMEN.COM NETWORKS, INC.                  EDIETS.COM, INC. By:  /S/ Bud Ward                         By: /S/ David R. Humble Name: Bus Ward                            Name: David R. Humble Title: Vice President Eastern Ad Sales    Title: CEO and Chairman 1820 Gateway Drive, Suite 150             3467 West Hillsboro Boulevard, Suite 2 San Mateo, CA 94404                       Deerfield Beach, FL  33442 Voice: (650) 378-6500                     Voice: (954) 360-9022 Fax:   (650) 378-6599                     Fax:   (954) 360-9095 15 EXHIBIT A [GRAPHIC OMITTED] A-1 EXHIBIT B 

# DIET CENTER LOGO 

eDiets will have the following Channel and Subchannel Center Logo Placements 

(1)      Health Channel Home Page and Two Sub Channels of Choice http://www.women.com/health/ 2 Sub Channels: Health News http://www.prevention.com/healing/ Condition & Ailments http://www.prevention.com/healing/cond_ail/ Estimated Impressions per month- 160,000 Estimated Impressions for Year 1- 1,920,000 Estimated Impressions for Year 2- 1,920,000 Total Estimated Impressions: 3,840,000 OR (2)      Food Channel Home Page and Two Sub Channels of Choice http://food.homearts.com/food/ 2 Sub Channels: Restaurants http://food.homearts.com/food/restaura/00rest17.htm Food For Thought http://food.homearts.com/food/thoughts/00thou17.htm 

Estimated Impressions Per month- 300,000 

Estimated Impressions for Year 1- 3,600,000 Estimated Impressions for Year 2- 3,600,000 

Total Estimated impressions: 7,200,000 

(3)      Fitness Channel Home Page and Two Sub Channels of Choice 

http://www.women.com/fitness/ 

2 Sub Channels 

Weight Loss http://www.prevention.com/weight/getstart.html 

Fitness News http://www.prevention.com/weight/ 

Estimated Impressions per month- 60,000 (before re-launch) Estimated Impressions for Year 1- 720,000 Estimated Impressions for Year 2- 720,000 Total Estimated impressions: 1,440,000 

B-1 

Upon committing to this partnership, eDiets will receive a two-week banner advertisement test in rotation across the channels set forth above in order to determine the most suitable fixed placements for the eDiets center logos. This test will consist of a total of 100,000 impressions, 20,000 per channel. Given that expectations for banner advertisement performance are not necessarily equivalent to that of a fixed center logo, eDiets understands and acknowledges that the results will be considered directional in nature and not used to determine ultimate performance of the eDiets center logos placed in the channels selected by eDiets. 

The parties may agree at a later date to add other channels to the above list of channels. In any event, eDiets may select from only three channels. 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

PROMOTION OF DIET CENTER ON WOMEN.COM SITES 

Relevant Feature Content Sponsorships 

Women.com will provide eDiets with a fixed top and 125x365 side banner on eight 

(8) of the content features set forth below. 

eDiets may select up to eight (8) of the content features set forth below: (1) Fat to Firm at 40+ (Estimated Impressions per Month- 7,000) http://www.prevention.com/weight/fattofirm/ 

(2) Nutrition News - If you make one change to your diet, what would it be? (This is an Expert piece) (Estimated Impressions per Month- 10,000) http://www.prevention.com/cooking/news/ 

(3) 71 Weight Loss Tips (Estimated Impressions per Month- 100,000) 

http://www.prevention.com/report/980610/ 

(4) Weight Loss Program - Working Out (Estimated Impressions per Month- 15,000) http://www.healthyideas.com/weight/workout.html 

(5) 45 Best and Worst Belly Flatteners (pull down menu to select scenarios with exercise tips) (Estimated Impressions per Month- 7,000) 

http://www.healthyideas.com/report/bellyflat/ 

(6) 8 Ways to Make Weight lifting fun (Estimated Impressions per Month- 16,000) http://www.prevention.com/weight/buzz/ 

(7) Gym Shorts (Q&A Michelle Staten, Fitness Editor, Prevention) (Estimated Impressions per Month- 10,000) http://www.prevention.com/weight/gym/ 

(8) Calorie Calculator (Tool) (Estimated Impressions per Month- 20,000) http://www.prevention.com/weight/bonfire/ 

(9) Weight Loss Program: Success Stories (Estimated Impressions per Month17,000) 

B-2 

www.prevention.com/weight/success.html 

(10) Weight Quiz: What will you Weigh one Year from now? (Quiz) (Estimated Impressions per Month- 39,000) www.prevention.com/weight/what_will_you/ 

(11) Weight Loss Program Planner (Tool) (Estimated Impressions per Month50,000) www.prevention.com/weight/planner/ 

(12) A Choice of one top level sponsorship in the newly launched Fitness Channel scheduled for 3Q, 2000 

eDiets.com will have the first right to substitute any of the following content features for any of the eight (8) content features selected above once inventory on such features becomes available. When the following content features become available, eDiets.com has the choice to switch sponsorships and not add to their overall sponsorships. 

(1) Weight Loss Program: Finding Support (Available 6/30/01) (Estimated 

Impressions per Month- 2,000) www.prevention.com/weight/support.html 

(2) Weight Loss Program: Eating Well (Available 6/30/01) (Estimated Impressions per Month- 2,000) www.prevention.com/weight/eatwell.html 

(3) Weight Loss Program: Getting Started (Available 6/30/01) (Estimated Impressions per Month- 7,000) www.prevention.com/weight/getstart.html ROS advertisement rotation on Women.com Sites 

The Following Advertising Impressions will include these campaign elements: 

-All Sponsorships 

-Targeted Banner Rotations (Targeted rotation includes Fitness, Entertainment, Wedding, Health, Fashion & Beauty, Food Channels, Redbook, Cosmopolitan, Prevention, Good Housekeeping, eHarlequin and Home and Garden and other relevant areas as they become available) -ROS 

Per Year 

o  Impressions Guaranteed per month:           3,750,000 

o  Total Advertising Impressions Guaranteed:   45,000,000 (of which shall not include the top 468x60 nor the 120x240 banner located on the Gateway page of the Diet Center) 60% ROS and 40% Targeted and Sponsorship elements 

B-3 

o Ad banners on the Diet Center will be co-branded with the Women.com and eDiets logos 

Women.com Special Membership Integration Opportunities: 

Women.com will provide eDiets with one (1) membership offer opportunity to Women.com users who have registered for membership on the Women.com Sites per 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

quarter after the Effective Date. These member offers will be promoted via membership newsletters as listed below, on the Membership Menu Page (http://women.com/membership/central.html) and on the Promotion Page (http://women.com/promotions/). The member offer provided by eDiets can not run anywhere other than Women.com for one month prior to or one month after the member promotion period without Women.com's written consent 

eDiets shall offer in any membership offer provided pursuant to this Agreement a minimum discount of 20% on the fair market value of any products or services. 

Placement within Women.com Newsletters: 

eDiets.com will have the opportunity to participate within the following newsletters, the placement, frequency and timing of such participation to be determined by Women.com in its sole discretion provided that Women.com uses its best efforts not to place reference to eDiets on the same page as content which may appear to be contrary to the basic foundation of the eDiets' philosophy. During the Term, eDiets.com will be guaranteed 12 million circulation per year from and after the Effective Date via newsletters, including but not limited to: >>  Fashion & Beauty Newsletter: 300,000 subscribers per month >>  Food News: 180,000 subscribers per month >>  Prevention: 1,600,000 subscribers per month >>  Internet Scopes:  2,400,000 subscribers per month >>  Sex & Romance: 120,000 subscribers per month 

>>  What's New: 1,100,000 subscribers per month 

>>  Women.com Member Newsletter: 1,700,000 subscribers per month 

Guaranteed Circulation Per Year:            12,000,000 

Anchor Tenancy Sponsorship of the Women.com Promotions/ Sweepstakes: 

Women.com will provide eDiets.com with three (3) Anchor Sponsorships and two (2) Premier Sponsorships of the following Women.com promotions. 

The "Anchor Sponsorship" includes the following elements: 

o Grand prize sweepstakes opportunity 

o Exclusive sponsorship of an editorial feature showcased within the promotion o Availability to ask two (2) demographic or brand research questions o Full database of names collected from the sweepstakes (estimated 30,000 to 60,000 names), the use of which is subject to all applicable Women.com privacy policy. 

o Network wide promotion of the sweepstakes, the placement, size, frequency and timing of such promotions to be determined by Women.com in its sole discretion. 

B-4 

Included in a "Premier Sponsorship" are all of the following elements: o 1/st/ place sweepstakes opportunity 

o Co-sponsorship of an editorial feature showcased within the promotion 

o Full database of names collected from the sweepstakes (30,000 to 60,000 names) o Network wide promotion of the sweepstakes, the placement, size, frequency and timing of such promotions to be determined by Women.com in its sole discretion. 

Available Promotions for Participation: o Wedding Promotion  (Year 2000) o Holiday Survival Guide (Year 2000) o Resolutions Promotion (Year 2001) o Valentine's Day Promotion (Year 2001) o Mother's Day Promotion (Year 2001) 

Total estimated impressions per promotion:           1,000,000 

Women.com E Commerce Elements: 

Sports/Fitness Diet Center Homepage: http://www.women.com/shopping/webstoreguide/sports/ 

o Rotating "Featured Partner" Ad Button on the side of the page 

All Sub Categories: 

o Rotating "Featured Partner" Ad Button on the side of the page 

o Affiliate text link placement within all sub-sub categories 

- New category creation at a minimum of 3 weeks from receipt of all coded links, descriptions and images have been received from client. Note: if category requires the participation of more than one client, it will not be created until all material has been received from all participants. 

Impression Break-Out Per Year: 

Advertising Impressions:                          Estimated           Guaranteed -Sponsorships and Targeted Rotations:         18,000,000 -ROS                                          27,000,000 Total Guaranteed Advertising Impressions:                             45,000,000 QUARTERY IMPRESSION  GUARANTEED                                       11,250,000 Diet Center, Channel & SubChannel Impressions:                                      Estimated           Guaranteed 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

"eDiets Diet Center" logo impressions:           30,000,000 

B-5 

"eDiets Diet Center" logo impressions:                               13,000,000 Other Campaign Impressions:                       Estimated           Guaranteed Newsletters                                                           12,000,000 Promotions                                        500,000 Added Value Commerce Impressions:                 3,600,000 Total Estimated Impressions:                      79,100,000 Total Impressions Guaranteed:                                         70,000,000 B-6 EXHIBIT C PAYMENT SCHEDULE Pricing/Delivery: PRICING AS PART OF THIS PACKAGE ONLY Flight:                             2 Year Deal Net Advertising CPM:                $37.00 (Just Co-Branded Banners) Overall Net CPM                     $28.57 (With all other elements) Total Net Cost:                     $2,000,000 (Per Year)/$4,000,000 (Two Years) Total Guaranteed Impressions:       70,000,000 (Per Year)/140,000,000 (TwoYears) 

# YEAR 1 

10 days after Effective Date-Production                                 $250,000 Last day of each of the 1st through 12/th/ months after the Launch Date                                                 $145,833 Media Component                                       $138,750 Other (Promotions, production, etc)                     $7,083 YEAR 2 Last day of each of 13/th/ through 24/th/ months after the Launch Date                                                 $166,666 Media Component                                       $138,750 Other (Promotions, production)                      $27,916.66 Total Payment to Women.com                                            $4,000,000 [GRAPHIC OMITTED] 

C-1 

EXHIBIT D 

# GENERAL ADVERTISING & PRODUCTION GUIDELINES 

The following are the Women.com advertising and production guidelines. Any exceptions to these guidelines require prior written approval of Women.com. 

All impressions per section are estimated; however, Women.com shall extend every reasonable effort to deliver the estimated number of impressions per section as set forth in Exhibit B. Notwithstanding the foregoing, Women.com does guarantee a minimum of 13,000,000 impressions promoting eDiets per year on the Diet Center. 

# BANNER CREATIVE & STANDARDS 

All campaigns must submit 468x60, 234x60, and 125x365 creative units. 

1.    ACCEPTED BANNER SIZES 

o  234x60 half-banner (8k or less) 

o  468x60 banner (10k or less) 

o  125x365 sponsorship (12K or less) 

o  125x125 promo (8K or less; reserved for marketing and co-branded tagged tune-ins with management approval) 

2.    BANNER CREATIVE FORMATS ACCEPTED 

o  GIF (animated and non-animated) 

o  JPEG 

o  HTML 

o  JAVASCRIPT 

3.    THE FOLLOWING ADDITIONAL FORMATS CAN POTENTIALLY BE USED BUT REQUIRE ADDITIONAL PRODUCTION AND TESTING TIME TO ENSURE NETWORK COMPATIBILITY: 

o  JAVA 

o  ENLIVEN o  UNICAST o  FLASH 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

Please check with ad production regarding other formats. 

D-1 

# PRODUCTION LEAD TIME AND "SHIP TO" INFO 

# Lead Times 

The following lead times should be considered standard. Additionally, more extensive campaigns/sponsorships and/or incorporating new technologies may take longer. 

o Banner campaigns require 5 business days from the time all advertiser materials/instructions are received. 

o Creative rotation changes/refreshes require 3 business days from the time all advertiser materials/instructions are received. 

# "Ship To" Info 

All creative should be sent to ads@women.com. 

ADVERTISING/LINKS - CATEGORIES NOT ACCEPTED 

The following categories of advertising or links to such material are not accepted on Women.com: 

o Tobacco 

o Controlled substances 

o Liquor 

o Firearms 

o Gambling 

o Sexually explicit advertising and/or advertising that is degrading. o Women.com, specifically Prevention on-line (Healthy Ideas) cannot accept advertising that promotes: 1) a product deemed defective or unsafe by the FDA, 2) a product, therapy or service whose possible harm to the consumer outweighs it benefits, and 3) a health product for which there is no good evidence of benefit and no good reason to believe there is a benefit. 

# THIRD PARTY AD SERVING 

Women.com accepts third party ad serving. However, third party serving relies on the third party's servers being fully operational. If Women.com determines that the servers are unreliable, the banners must be served from Women.com's site until such time the third party servers are fully operational. Also note that Women.com cannot track click-thrus in its NetGravity reports for rich media banners that are served remotely. 

Women.com must be notified in writing regarding the product categorizations of all creative rotations as well as any revisions, in order to maintain proper placement and competitive separation. Any changes made to creative rotations without prior notification to Women.com may result in the interruption or temporary discontinuation of ad delivery until all ad placements and competitive separation issues can be resolved. 

# NETWORK DESIGN CONFIGURATION 

D-2 

Women.com reserves the right to make design and configuration changes to all pages and features within the network. Women.com shall notify its advertisers of any changes that significantly impacts ad placements. 

D-3 

Source: EDIETS COM INC, 10QSB, 10/30/2000 

