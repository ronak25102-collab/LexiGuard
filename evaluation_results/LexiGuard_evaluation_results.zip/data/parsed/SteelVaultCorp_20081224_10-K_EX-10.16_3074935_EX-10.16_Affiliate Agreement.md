**Exhibit 10.16** 



# **MARKETING AFFILIATE AGREEMENT** 

This Agreement is made this 1<sup>st</sup> day of October 2008, (the “Effective Date”), by and between Equidata, Inc., a corporation organized under the laws of Virginia with its principal place of business at 724 Thimble Shoals Boulevard Newport News, Virginia 23606 (“Equidata”), and National Credit Report.com, LLC a Corporation organized under the laws of Florida, with its principal place of business at 7700 N. Congress Ave, Suite 3113, Boca Raton FL33487 (“Marketing Affiliate”). 

# **<u>RECITALS</u>** 

1. Equidata provides certain personal credit, fraud detection, credit scoring services and credit monitoring for consumers, the (“Services”). 

2. Marketing Affiliate and Equidata wish to enter into an agreement under which Marketing Affiliate may market the Services. 

3. Marketing Affiliate wishes to market the Services indirectly through third party programs, direct mail, Internet and both inbound and outbound telemarketing. In addition, each may own and operate a web site utilizing direct access to the Services through Internet links. 

Therefore, if accepted all parties agree that the following shall constitute a marketing agreement between the parties. 

# **<u>TERMS AND CONDITIONS</u>** 

**Permission.** Subject to the terms and conditions of this Agreement, Marketing Affiliate may display Marketing Materials at its principal place(s) of business, or at the principal place(s) of its third party partners, together with a link from the Marketing Affiliate Web Site to Fquidata (and its partners) Web Site. Marketing Materials may also be used in the marketing of potential customers through direct mail and personal solicitation as well as inbound and outbound telemarketing. Marketing Affiliate may not otherwise offer for sale, market, sell or distribute the Services of Equidata without express written permission. 

**1. Compensation.** Marketing Affiliate shall be responsible for collecting all amounts due directly from the Consumer and shall bear sole responsibility for non-payment of any fees charged to the Consumer. Marketing Affiliate shall pay to Equidata, as compensation for its providing of Services under this agreement, such amounts as outlined and detailed in Exhibit A attached hereto. Such amounts shall be billed on a bi-monthly basis by Equidata and are due and payable in full by Marketing Affiliate 30 days from the invoice date. The prices set forth in Exhibit A do not include regulatory fees, sales tax, excise tax or any other fees or taxes that may be charged by states or local taxing authorities nor does it include additional fees or surcharges, including specific area Affiliate charges that may be accessed by the Credit Reporting Agencies (CRA’s). Said amounts charged to Equidata will be billed separately to Marketing Affiliate and are due immediately upon receipt. Marketing Affiliate agrees to reimburse Equidata all costs of collecting any past due amounts from Marketing Affiliate by reason of non payment, including reasonable attorney fees and disbursements. Equidata reserves the right to increase the base cost of Services. Notice will be given to Marketing Affiliate in writing no less than 30 days prior to such increase taking affect. A development fee, yet To Be Determined and outlined in Exhibit A, is due upon a signed agreement of project scope. 

Marketing Affiliate agrees to pay promptly and in full all charges incurred through services rendered when billed. When paying by credit card, the Marketing Affiliate agrees to pay for all items that are revoked or disputed by the credit card company or the card holder along with any charges or fees charged by the credit card company including fees associated with processing the credit card transaction and that the Marketing Affiliate will be billed for those items in accordance with Equidata standard practices. Marketing Affiliate and the undersigned principal, partner or owner further agree that this Agreement will serve as a personal guaranty by the undersigned principal, partner or owner of the company, and the undersigned principal, partner or owner will become responsible for any unpaid balance past due on any invoice. The Marketing Affiliate agrees to pay a late charge of 1<sup>l</sup> /2% per month on the unpaid, past-due amount as well as a returned check fee of not less than $35.00 per returned item. In addition, the Marketing Affiliate agrees to pay 25% attorney’s fees plus court cost in the event that the Marketing Affiliate’s account is referred to an attorney for collection. 

**2. Disputes.** In the case of disputed charge, defined as a non-payment of an invoice for which notice of dispute has been given in writing by Marketing Affiliate to Equidata, Equidata or Marketing Affiliate may choose arbitration and Marketing Affiliate and Equidata shall be obligated by the terms agreed upon by arbitration and all monies determined owed shall be considered due and payable immediately. Such arbitration does not relieve Marketing Affiliate from its obligation to promptly pay for undisputed charges in accordance with the terms of this Agreement. Such disputes shall be settled by arbitration in the City of Newport News, Virginia. 

Marketing Affiliate shall give Equidata written demand of dispute within 10 days of the due date of the invoice. The demand shall set forth a statement for the nature of the dispute and the amount involved. If Equidata and Marketing Affiliate can not resolve the dispute on their own within 10 days after Equidata receive said dispute, the parties shall jointly select an arbitrator. 

Initials: /s/ IP 

Source: STEEL VAULT CORP, 10-K, 12/24/2008 

If the parties do not agree on the selection of an arbitrator, each party will select an arbitrator of their choosing, and the two arbitrators will jointly select a third arbitrator(s). Not later than 5 calendar days after the arbitrator(s) have been selected, the arbitrator(s) shall schedule the arbitration hearing to commence on a mutually convenient date. The hearing shall commence no later than 25 calendar days after Equidata receives receipt of dispute from Marketing Affiliate and shall continue from day to day until completed. The arbitrator(s) shall issue an award in writing no later than 10 calendar days after the conclusion of the hearing. The arbitration award shall be final and binding on both parties. 

**3. Operational Specifications.** Marketing Affiliate and Equidata shall agree upon Operational Specifications pertaining to the methodology and logistics of data transfer and database coordination. Upon mutual agreement as to the Operational Specifications, they shall be deemed to be a part of this Agreement by way of an Exhibit. Both parties must agree upon any changes to the Operational Specifications in writing. Any such changes will be deemed to be a part of the Operational Specifications. 

**4. Non-solicitation of Clients.** Marketing Affiliate shall not directly or indirectly solicit an existing business customer of Equidata during the term and condition of this Agreement other than for joint marketing purposes. Further, Marketing Affiliate shall not market similar products from competing companies on any Web Site Landing Page containing the Equidata or Marketing Affiliate Web link as long as this Agreement is in effect. 

**5. Compliance.** Marketing Affiliate nor Equidata, shall engage in any practice or activity that is not in compliance with the Fair Credit Reporting Act (FCRA), the Fair Debt Collection Practices Act (FDCPA) and the Health Insurance Portability and Accountability Act (HIPAA) as well as, but not limited to, any practice or activity that: 

   - 5.1. Violates any applicable law or regulation; including but not limited to the sale of illegal goods or the violation of export control or obscenity laws; that invade the privacy of any third party; that are in any way connected with the transmission of “junk mail”, “spam” or the unsolicited mass distribution of e-mail, or with any unethical marketing practices. 

   - 5.2. Is misleading, deceptive, confusing or abusive as outlined in the Telemarketing Fraud Prevention Act; 

   - 5.3. Makes any representation or statement, or grants any warranty or creates any other obligation with respect to the Services, that is in addition to or otherwise inconsistent with any representation, statement or warranty stated expressly by Equidata. 

   - 5.4. Uses Marketing Materials, media or methods that are not approved, including, but nor limited to telemarketing scripts. Such approval shall not be unreasonably withheld and shall be completed within 48 hours of receipt of Marketing Materials for review. 

   - 5.5. Does not meet the standards for good industry practices for the direct marketing industry. 

   - 5.6. Further guidelines and requirements are provided in Exhibit B and C. 

**6. Audit.** Equidata may audit, at Equidata’s expense, the Marketing Affiliate’s marketing, practices and activities for the purpose of assuring compliance with this Agreement. Equidata reserves the right to site inspect Marketing Affiliate’s physical location of business at any time. 

**7. Term and Termination.** This Agreement commences on the Effective Date, and terminates, along with all licenses and authorizations granted under it, upon the earliest of termination in accordance with the following. 

   - 7.1. This Agreement shall be for the term of one year; thereafter, the Agreement shall renew automatically under these same terms and agreements unless superceded by future agreements. 

   - 7.2. This Agreement may be terminated by either party with cause upon thirty (30) days written notice. Upon Marketing Affiliate’s default in payment or other breach of this Agreement, Equidata may terminate this Agreement without notice to Marketing Affiliate. Upon termination for any reason, Equidata reserves the right to deactivate Marketing Affiliate’s access to the services including the Equidata Web Site. Termination does not release Marketing Affiliate from paying all amounts owed to Equidata. 

   - 7.3. At time of Agreement termination, Marketing Affiliate shall immediately remove all URL related data pertaining to said Agreement; and if data is not voluntarily removed, Equidata reserves the right to use all available legal resources to force the removal of Equidata URL related data and Marketing Affiliate agrees to be liable for the cost of such action, including but not limited to reasonable attorney fees. 

   - 7.4. Equidata reserves the right to terminate this Agreement immediately for cause if Experian, Equifax and/or TransUnion (Credit Reporting Agencies — CRAs) decline to render Services to Marketing Affiliate for any reason or if Equidata is notified by any of the CRAs to cease rendering Services to Marketing Affiliate. 

**8. Representations and Warranties.** Marketing Affiliate represents and warrants that: 

   - 8.1 Marketing Affiliate does not engage in any business with respect to, and the Marketing Affiliate Web Site will not be used, or display any materials, in any form or medium, in connection with a credit clinic, credit repair or restoration, credit counseling firm, financial counseling firm, detective agency, private investigation, security services, practice of law, news reporting or journalism, or fraudulent or unethical conduct. 

   - 8.2. The information regarding Marketing Affiliate set forth in this Agreement, and the information provided to Equidata with respect to Marketing Affiliate and the Marketing Affiliate Web Site, is accurate; and 

   - 8.3. Marketing Affiliate’s business, including without limitation any business conducted in connection with the Marketing 

Source: STEEL VAULT CORP, 10-K, 12/24/2008 

Affiliate Web Site, does not violate any applicable law, regulation, court order or material agreement to which Marketing Affiliate is subject. 

- 8.4. Equidata warrants that it is an authorized provider of the Services as outlined in this Agreement and that it has the ability to provide said Services in the manner described herein. 

Page 2 of 3 

Initials: /s/ IP 

Source: STEEL VAULT CORP, 10-K, 12/24/2008 

**9. Indemnification.** Equidata and Marketing Affiliate each hereby agree to defend, indemnify and hold harmless each other and each of its employees, agents, officers, directors and shareholders from and against any claims, suits, demand or actions arising from breach of any warranties under this Agreement or failure to provide Services under this Agreement. 

**10. Proprietary Information.** Marketing Affiliate and Equidata mutually acknowledge that from time to time Confidential Information may be received by each. Confidential Information, includes, but is not limited to, Customer names and lists. The Receiving Party may not disclose or use the Disclosing Party’s Confidential and Proprietary Information for any reason other than in the performance of this Agreement. It is agreed any information received or collected by Marketing Affiliate about its Customers or potential Customers, including information used to enroll Customers is Proprietary as defined by this section and will not be used by Equidata in any manner other than as outlined herein. 

**11. Liability.** MARKETING AFFILIATE ACKNOWLEDGES AND AGREES THAT ANY PRODUCT, SERVICE, LICENSE OR PERMISSION PROVIDED BY EQUIDATA UNDER THIS AGREEMENT IS PROVIDED ON AN “AS IS” BASIS. EQUIDATA EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY KIND WHATSOEVER, WHETHER EXPRESS, IMPLIED, STATUTORY, OR ARISING FROM COURSE OF DEALING OR PERFORMANCE, AND HEREBY DISCLAIMS AND EXCLUDES FROM THIS AGREEMENT ALL IMPLIED WARRANTIES, INCLUDING WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NONINFRINGEMENT, NONINTERFERENCE WITH DATA, ACCURACY, OR THAT THE SERVICE IS ERROR FREE. IN NO EVENT WILL EQUIDATA BE LIABLE FOR ANY INDIRECT, EXEMPLARY, PUNITIVE, SPECIAL, OR CONSEQUENTIAL DAMAGES INCLUDING WITHOUT LIMITATION LOST PROFITS OR OTHER ECONOMIC LOSS, LOST REIMBURSEMENTS, AND LOST DATA, OR FOR ANY CLAIM BY ANY THIRD PARTY. EVEN IF EQUIDATA, MARKETING AFFILIATE OR BOTH HAD BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES OR CLAIM, MARKETING AFFILIATE AGREES TO DEFEND, INDEMNIFY AND HOLD HARMLESS EQUIDATA, AND EACH OF ITS EMPLOYEES, AGENTS, OFFICERS AND DIRECTORS, FROM AND AGAINST ANY CLAIM, SUIT, DEMAND, OR ACTION, INCLUDING WITHOUT LIMITATION ATTORNEY FEES, ARISING FROM (A) BREACH OF THIS AGREEMENT BY MARKETING AFFILIATE, (B) THE MARKETING AFFILIATE WEB SITE, OR (C) MARKETING AFFILIATE’S BUSINESS. 

**12. Miscellaneous.** This Agreement binds and inures to the benefit of each party’s permitted successors, assigns and legal representatives, including the purchasers of the stock or assets of either party hereto. No delegation by either party of any duty hereunder shall be deemed an assignment of this Agreement, nor shall any change in control or an assignment of by operation of law by either party be deemed an assignment hereunder. Any failure or delay in exercising, or any single or partial exercise of, any right or remedy by either party may not be deemed a waiver of any further, prior, or future right or remedy hereunder. This Agreement is governed by and construed in accordance with the laws of the State of Virginia. All notices required to be given in writing must be sent by overnight delivery service to the name and address designated in this Agreement or to such other address that the receiving party may in advance designate by written notice. Notice is deemed effective on the day after delivery by the overnight carrier. If any provision of this Agreement is declared invalid, the other provisions remain in full force and effect and this Agreement is deemed to be amended to replace, to the extent legally possible, the rights and obligations contained in the invalid provision. The invalidity of any provision is not a failure of consideration. The Parties shall operate as Independent Contractors in performing their obligations under the Agreement and shall have exclusive control of the manner and means of performing such obligations. Each party shall be solely responsible for supervision, daily direction and control of its employees and payment of their salaries, worker’s compensation, disability and other benefits. Nothing in the Agreement shall be construed as making either party the agent of the other party, as granting to the other party the right to enter into any contract on behalf of the other party, or as establishing an association, franchise, joint venture or partnership between the Parties. Under no circumstances shall the employees of one party be deemed to be employees of the other for any purpose. This Agreement constitutes the entire understanding of the parties with respect to the subject matter hereof, and supersedes all prior or contemporaneous agreements, statements and representations, oral or written, between the parties relating to the subject matter of the Agreement. No representation or promise, or modification or amendment to this Agreement is binding on either party unless in writing signed by authorized representatives of both parties. 

# **Accepted and Agreed:** 

**Executive two (2) copies and return executed copies to:** 

**Company Name:** Equidata, Inc. **Marketing Affiliate Name:** National Credit Report LLC **Address:** 724 Thimble Shoals Blvd. Newport News, VA 23606 **Address:** 7700 N Congress AVE, Suite 3113 Boca Raton, FL 33487 **Phone Numbers:** 757-873-0519 / 800-288-9809 **Phone Numbers:** 561-910 8900 Fax: 757-873-1224 **Email Address:** Kchase@equidata.com **Email Address:** ivan.posniak@nationalcreditreport.com **Print Name:** Kitty Chase **Print Name:** Ivan Posniak **Title:** SVP **Title:** CEO **Signature:** /s/ Kitty Chase **Signature:** <u>/s/ Ivan Posniak</u> Page 3 of 3 Initials: /s/ IP 

Source: STEEL VAULT CORP, 10-K, 12/24/2008 

