# MASTER SOFTWARE DEVELOPMENT & SERVICES AGREEMENT (MSA) 

**Effective Date:** October 15, 2024 

**Agreement Number:** MSA-2024-8849-V2 

This Master Services Agreement ("Agreement") is entered into by and between: 

* **Apex Enterprise Solutions, Inc.**, a Delaware corporation having its principal office at 500 Tech Parkway, Austin, TX ("Client" or "Company"), and 

* **Vortex Digital Dynamics LLC**, a California limited liability company having its principal office at 100 Innovation Way, San Francisco, CA ("Vendor", "Developer", or "Service Provider"). 

--- 

### SECTION 1: DEFINITIONS & INTERPRETATIONS 

* **1.1 "Confidential Information"** shall mean all proprietary, non-public technical, business, or operational data disclosed by either Disclosing Party to the Receiving Party. 

* **1.2 "Deliverables"** shall mean the software modules, API integrations, documentation, and source code specified in Statement of Work #1 (SOW-1). 

* **1.3 "Force Majeure Event"** shall have the meaning set forth in Section 11.1. 

--- 

### SECTION 2: SCOPE OF SERVICES & MILESTONES 

* **2.1 Milestone Schedule:** The Developer shall deliver the milestone deliverables according to the schedule set forth in Table 2.1 below: 

| Milestone ID | Description | Target Delivery Date | Fixed Fee (USD) | | :--- | :--- | :--- | :--- | 

| **M-101** | Core API Architecture & Database Schema | Nov 15, 2024 | $25,000 | | **M-102** | Payment Gateway Integration (PCI-DSS) | Dec 30, 2024 | $40,000 | | **M-103** | Final UAT Deployment & Load Testing | Feb 15, 2025 | $35,000 | 

* **2.2 Acceptance Window:** The Client shall have ten (10) business days from delivery of each Milestone to inspect and provide written acceptance or rejection. 

--- 

### SECTION 3: COMPENSATION & LATE DELIVERY PENALTIES 

* **3.1 Payment Terms:** Undisputed invoices are payable Net-30 from date of receipt by Client. * **3.2 Delay Liquidated Damages:** Subject to the exceptions detailed in Section 3.3 and Section 11.2, if the Service Provider fails to deliver any Milestone by the Target Delivery Date in Table 2.1, the Service Provider shall pay a late penalty of **1.5% of the Milestone Fee per calendar day of delay**, capped at a maximum of **20% of the total Milestone Fee**. * **3.3 Exemption to Late Penalties:** The penalty clause in Section 3.2 shall be null and void if: 

* (a) The delay is directly attributable to the Client’s failure to grant API access or provide feedback within the acceptance window defined in Section 2.2; OR 

* (b) A qualified Force Majeure event is declared pursuant to Section 11.1. 

--- 

### SECTION 4: INTELLECTUAL PROPERTY & OWNERSHIP 

* **4.1 Work Made for Hire:** Upon full payment of the applicable Milestone Fees, all Deliverables shall be considered "work made for hire" and become the sole property of Apex Enterprise Solutions, Inc. 

* **4.2 Pre-Existing IP:** The Vendor retains all rights, title, and interest in its proprietary developer libraries, pre-built components, and standard utility functions ("Vendor Core Tools"). Vendor grants Company a perpetual, worldwide, royalty-free, non-exclusive license to use Vendor Core Tools embedded within the Deliverables. 

--- 

### SECTION 5: CONFIDENTIALITY & NON-DISCLOSURE 

* **5.1 Obligation:** Each party agrees to protect the Confidential Information of the other using the same degree of care it uses for its own sensitive data, but no less than reasonable care. * **5.2 Breach Penalties:** In the event of an unauthorized disclosure of Confidential Information by Receiving Party, Receiving Party shall pay liquidated damages of **$150,000 per violation**, plus direct damages incurred. 

--- 

### SECTION 6: INDEMNIFICATION & THIRD-PARTY CLAIMS 

* **6.1 Vendor Indemnity:** Vendor shall defend, indemnify, and hold harmless Client, its officers, and employees against any third-party claims alleging that the Deliverables infringe any patent, copyright, or trade secret. 

* **6.2 Client Indemnity:** Client shall indemnify Vendor against claims arising from content, datasets, or software components provided directly by Client. 

--- 

# ### SECTION 7: LIMITATION OF LIABILITY 

* **7.1 General Aggregate Cap:** Except as expressly provided in Section 7.2, each party’s total aggregate liability arising out of or related to this Agreement shall be limited to the **total fees actually paid by Client to Vendor under this Agreement in the preceding six (6) months**. 

* **7.2 Carve-Outs / Super-Cap:** The liability limitation established in Section 7.1 **SHALL NOT APPLY** to: 

- (i) Breach of Confidentiality obligations under Section 5; 

- (ii) Indemnification obligations under Section 6; OR 

- (iii) Willful misconduct or gross negligence. 

* For breaches falling under (i) above, liability shall be capped at a super-cap limit of **$500,000**. 

--- 

### SECTION 8: TERM & TERMINATION 

* **8.1 Term:** This Agreement commences on the Effective Date and continues until terminated. 

* **8.2 Termination for Convenience:** Client may terminate this Agreement without cause upon giving thirty (30) days prior written notice to Vendor. 

* **8.3 Early Termination Fee:** If Client terminates under Section 8.2 prior to the completion of Milestone M-103, Client shall pay a termination fee of **$15,000** to reimburse Vendor for unrecoverable resource allocations. 

* **8.4 Termination for Cause:** Either party may terminate immediately if the other party breaches a material term and fails to cure such breach within fifteen (15) days of written notice. 

--- 

### SECTION 9: GOVERNING LAW & DISPUTE RESOLUTION 

* **9.1 Jurisdiction:** This Agreement shall be governed by and construed in accordance with the laws of the **State of Delaware**, without regard to conflict of law principles. 

* **9.2 Arbitration:** Any dispute arising out of this Agreement shall be settled by binding arbitration administered by JAMS in Wilmington, Delaware. 

--- 

### SECTION 10: MISCELLANEOUS & SURVIVAL 

* **10.1 Survival:** Sections 1, 4, 5, 6, 7, 9, and 10 shall survive the expiration or termination of this Agreement. 

* **10.2 Entire Agreement:** This Agreement and attached SOWs constitute the entire understanding between the parties, superseding all prior oral or written agreements. 

--- 

# ### SECTION 11: FORCE MAJEURE 

* **11.1 Definition:** Neither party shall be liable for failure or delay in performing its obligations (excluding payment obligations) if such failure results from acts of God, war, pandemic, government sanctions, or catastrophic telecommunication outages. 

* **11.2 Notice Requirement:** The affected party must give written notice within forty-eight (48) hours of the event to invoke relief under Section 3.3(b). 

--- 

**IN WITNESS WHEREOF**, the parties have executed this Master Services Agreement as of the Effective Date. 

**FOR CLIENT (Apex Enterprise Solutions, Inc.):** Signature: *[Authorized Signatory]* Name: Sarah Jenkins Title: VP of Engineering 

**FOR VENDOR (Vortex Digital Dynamics LLC):** Signature: *[Authorized Signatory]* Name: Marcus Vance Title: Managing Partner 

