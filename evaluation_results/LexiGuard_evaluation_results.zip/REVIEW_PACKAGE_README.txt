LexiGuard evaluation results

Start with output/pdf/LexiGuard_live_ablation_brief.pdf and docs/live_ablation.md.

This attachment contains reports, frozen questions/protocols, reference annotations,
source text, answers, per-query scores, source checks, executed Cypher/returned rows,
cached model responses and original scoring failures. Both live cohorts are included
separately; the initial negative pilot has not been removed or pooled with the fresh
24-question evaluation. Scores and raw records are unchanged.

It contains no executable application files. The source code and full reproduction
package, including exact measurement-source snapshots, are available on GitHub:
https://github.com/ronak25102-collab/LexiGuard
https://github.com/ronak25102-collab/LexiGuard/blob/main/evaluation_results/LexiGuard_live_evaluation_package.zip

The data-only attachment is for inspecting the evidence. For a fresh replay, use
the full reproduction package and supply your own service credentials. Original
protocol hashes identify the exact measurement source retained in that package.

Every included file is covered by integrity_manifest.json, except the manifest.
No credentials or email drafts are included.
