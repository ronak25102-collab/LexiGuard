LexiGuard live evaluation review package

Start with output/pdf/LexiGuard_live_ablation_brief.pdf and docs/live_ablation.md.

Current result: 24 fresh questions / six contracts, all four variants complete.
Vector: faithfulness 0.959 / context precision 0.729.
Hybrid without CRAG: 0.941 / 0.465.
Hybrid + CRAG with evidence guard: 0.934 / 0.729.
CRAG restores precision lost by hybrid fusion; there is no aggregate gain over vector.

Both live runs are included. live_validation is the earlier negative 26-case pilot;
live_guard_validation is the subsequent independent cohort. Do not pool their means
as a before/after code effect. Historical offline reports are explicitly labeled.

Measurement source is under each run's measurement_source/ and matches protocol
start hashes. Root src/ contains current application code, including the format-only
JSON comma correction and an available NVIDIA default. No completed valid score was
selectively rejudged. Original malformed responses and the initial partial Google
run remain preserved.

To inspect existing data without inference:
uv sync --extra dev
uv run python scripts/11_live_ablation.py report --output evaluation_results/live_guard_validation
uv run python scripts/12_source_audit.py --output evaluation_results/live_guard_validation
uv run python scripts/15_guard_report.py

A new live replay requires your own Aura, Google embeddings, CodeCraft generation
and NVIDIA judge credentials in .env. Restore the saved corpus with script 10;
preserve the included answers/results before generating a new run. Cached prompts
and responses are retained for inspection. Graph reads always execute live; there
is no offline graph substitute in the benchmark. Clearing response caches produces
a new one-run measurement and may change the scores.

The annotation file includes unchanged CUAD entries for the 16 public contracts in
the restored corpus. Parsed .status files are included to preserve upload source IDs.
CUAD: Dan Hendrycks, Collin Burns, Anya Chen, Spencer Ball, NeurIPS 2021.
Original dataset: https://github.com/The-Atticus-Project/cuad
This is an independent application evaluation, not an official CUAD benchmark.

Credentials, screenshots, local vector binaries, server-runtime downloads and
node_modules are excluded. integrity_manifest.json verifies every delivered member.
The current Aura was tested; the existing Render service has not been redeployed.
See docs/cloud_deployment.md before claiming the hosted demo uses this configuration.
