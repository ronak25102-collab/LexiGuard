"""Tests for LexiGuard."""
