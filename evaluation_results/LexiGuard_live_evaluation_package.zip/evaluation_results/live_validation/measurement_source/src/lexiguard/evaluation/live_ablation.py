"""Adapters for a pinned-model evaluation against real Aura and persistent Chroma."""

from langchain_core.embeddings import Embeddings
from langchain_core.messages import AIMessage

from lexiguard.evaluation.focused_ablation import GoogleCalls
from lexiguard.evaluation.focused_ablation import digest, write_json
from lexiguard.config import get_settings
import json
import time
from pathlib import Path


class CachedGoogleEmbeddings(Embeddings):
    def __init__(self, calls: GoogleCalls):
        self.calls = calls

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self.calls.embed(texts).tolist()

    def embed_query(self, text: str) -> list[float]:
        return self.calls.embed([text], query=True)[0].tolist()


class PinnedGoogleChat:
    def __init__(self, calls: GoogleCalls):
        self.calls = calls

    def invoke(self, prompt) -> AIMessage:
        value = prompt if isinstance(prompt, str) else prompt.to_string()
        return AIMessage(content=self.calls.text(value))


class CachedCompatibleCalls:
    """Cache exact prompts and complete responses, isolated by endpoint and model."""

    def __init__(self, output: Path, provider: str, model: str):
        from openai import OpenAI
        settings = get_settings()
        self.model = model
        self.provider = provider
        self.key = getattr(settings, provider + "_api_key")
        self.endpoint = getattr(settings, provider + "_base_url")
        self.client = OpenAI(api_key=self.key, base_url=self.endpoint, timeout=90, max_retries=0)
        self.cache = output / "cache"
        self.cache.mkdir(parents=True, exist_ok=True)

    def text(self, prompt: str, model: str | None = None) -> str:
        model = model or self.model
        extra = {"chat_template_kwargs": {"enable_thinking": False}} if (
            self.provider == "nvidia" and "nemotron-3-" in model) else {}
        request = {"model": model, "temperature": 0, "max_tokens": 8192,
                   "messages": [{"role": "user", "content": prompt}], "extra_body": extra}
        path = self.cache / (digest([self.endpoint, request]) + ".json")
        if path.exists():
            return json.loads(path.read_text("utf-8"))["text"]
        for attempt in range(4):
            try:
                response = self.client.chat.completions.create(**request)
                choice = response.choices[0]
                if choice.finish_reason != "stop" or not choice.message.content:
                    raise RuntimeError("Model returned empty or incomplete output")
                value = choice.message.content.strip()
                write_json(path, {"provider": self.provider, "endpoint": self.endpoint,
                           "request": request, "response_model": response.model,
                           "text": value, "usage": response.usage.model_dump() if response.usage else None,
                           "finish_reason": choice.finish_reason})
                return value
            except Exception as error:
                status = getattr(error, "status_code", None)
                transient = status in {408, 429, 500, 502, 503, 504} or (
                    type(error).__name__ in {"APITimeoutError", "APIConnectionError"})
                if not transient or attempt == 3:
                    raise
                headers = getattr(getattr(error, "response", None), "headers", {})
                delay = min(60, max(2 ** (attempt + 1), float(headers.get("retry-after", 0))))
                print("PROVIDER_RETRY", self.provider, status, delay, flush=True)
                time.sleep(delay)
        raise RuntimeError("Retry exhausted")
