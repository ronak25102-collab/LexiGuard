"""FastAPI backend for LexiGuard."""
